package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CoinTransactionEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val authState by viewModel.authUiState.collectAsState()
    val wallet by viewModel.currentWallet.collectAsState()
    val todayEarnings by viewModel.todayEarnings.collectAsState()
    val totalEarnings by viewModel.totalEarnings.collectAsState()
    val pendingWithdrawal by viewModel.pendingWithdrawalAmount.collectAsState()
    val transactions by viewModel.currentTransactions.collectAsState()
    val adConfigs by viewModel.adConfigs.collectAsState()
    val streakDay by viewModel.streakDay.collectAsState()
    val isDailyClaimed by viewModel.isDailyClaimedToday.collectAsState()

    val availableCoins = wallet?.availableBalance ?: 0L
    val lockedCoins = wallet?.lockedBalance ?: 0L

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. User Header & Status (Sophisticated Dark layout)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WELCOME BACK",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = DarkTextSecondary
                    )
                    Text(
                        text = authState.currentUser?.name ?: "User",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                StatusChip(status = authState.currentUser?.status ?: "NORMAL")
            }
        }

        // 2. Main Balance Hero Card with Luxury Purple Gradient
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF4F378B), Color(0xFF381E72))
                        )
                    )
                    .border(1.dp, Color(0xFF6750A4).copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                    .padding(20.dp)
                    .testTag("user_balance_card")
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column {
                            Text(
                                text = "Available Balance",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFE8DEF8).copy(alpha = 0.8f)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = NumberFormat.getNumberInstance(Locale.US).format(availableCoins),
                                    style = MaterialTheme.typography.headlineLarge,
                                    fontWeight = FontWeight.Light,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Coins",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFFE8DEF8).copy(alpha = 0.7f),
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = null,
                                tint = PurplePrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    // Secondary Metrics Pill Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black.copy(alpha = 0.2f))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Today's Earned",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFE8DEF8).copy(alpha = 0.75f),
                                fontSize = 10.sp
                            )
                            Text(
                                text = "+${NumberFormat.getNumberInstance(Locale.US).format(todayEarnings)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = StatusSuccess
                            )
                        }

                        Column {
                            Text(
                                text = "Est. USD",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFE8DEF8).copy(alpha = 0.75f),
                                fontSize = 10.sp
                            )
                            Text(
                                text = String.format(Locale.US, "$%.2f", availableCoins / 1000.0),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = CoinGold
                            )
                        }

                        Column {
                            Text(
                                text = "Pending",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFE8DEF8).copy(alpha = 0.75f),
                                fontSize = 10.sp
                            )
                            Text(
                                text = "${NumberFormat.getNumberInstance(Locale.US).format(pendingWithdrawal)}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (pendingWithdrawal > 0) StatusWarning else Color(0xFFE8DEF8)
                            )
                        }
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.navigateTo(AppDestination.WALLET) },
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = PurplePrimary,
                                contentColor = PurpleDark
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Text("Withdraw Now", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.navigateTo(AppDestination.WALLET) },
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                        ) {
                            Text("Details", fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // 3. Quick Action Buttons (Earn, Tasks, Wallet, Refer)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickActionButton(
                    title = "Earn",
                    icon = Icons.Default.PlayCircle,
                    modifier = Modifier.testTag("quick_earn_button")
                ) {
                    viewModel.navigateTo(AppDestination.EARN)
                }

                QuickActionButton(
                    title = "Tasks",
                    icon = Icons.Default.AssignmentTurnedIn,
                    modifier = Modifier.testTag("quick_tasks_button")
                ) {
                    viewModel.navigateTo(AppDestination.TASKS)
                }

                QuickActionButton(
                    title = "Wallet",
                    icon = Icons.Default.AccountBalanceWallet,
                    modifier = Modifier.testTag("quick_withdraw_button")
                ) {
                    viewModel.navigateTo(AppDestination.WALLET)
                }

                QuickActionButton(
                    title = "Refer",
                    icon = Icons.Default.PersonAdd,
                    modifier = Modifier.testTag("quick_history_button")
                ) {
                    viewModel.navigateTo(AppDestination.PROFILE)
                }
            }
        }

        // 4. Daily Login Streak Bonus Widget (Requirement #9)
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(PurpleDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = null,
                                    tint = PurplePrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Daily Login Streak",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Day $streakDay / 7 • Up to 100 Coins",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = DarkTextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.claimDailyBonus() },
                            enabled = !isDailyClaimed,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isDailyClaimed) DarkSurfaceVariant else PurplePrimary,
                                contentColor = if (isDailyClaimed) DarkTextSecondary else PurpleDark,
                                disabledContainerColor = DarkSurfaceVariant,
                                disabledContentColor = DarkTextSecondary
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("claim_daily_bonus_button")
                        ) {
                            Text(
                                text = if (isDailyClaimed) "Claimed ✓" else "Claim",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // 7-day progress circles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val rewardSteps = listOf(10L, 20L, 30L, 40L, 50L, 75L, 100L)
                        rewardSteps.forEachIndexed { index, amount ->
                            val dayNum = index + 1
                            val isCompleted = dayNum < streakDay || (dayNum == streakDay && isDailyClaimed)
                            val isCurrent = dayNum == streakDay

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when {
                                                isCompleted -> PurplePrimary
                                                isCurrent -> PurpleDark
                                                else -> DarkSurfaceVariant
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (isCurrent) PurplePrimary else Color.Transparent,
                                            RoundedCornerShape(10.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isCompleted) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = PurpleDark,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        Text(
                                            text = "$amount",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCurrent) PurplePrimary else DarkTextSecondary
                                        )
                                    }
                                }
                                Text(
                                    text = "D$dayNum",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    color = DarkTextSecondary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Configured Third-Party Web Ad Banner Placement (HOME_TOP / HOME_MIDDLE)
        item {
            val homeBannerConfig = adConfigs.firstOrNull { it.placement == "HOME_TOP" && it.status == "ACTIVE" }
                ?: adConfigs.firstOrNull()
            if (homeBannerConfig != null) {
                AdBannerCard(adConfig = homeBannerConfig)
            }
        }

        // 6. Recent Transactions Preview
        item {
            SectionHeader(
                title = "Recent Transactions",
                actionLabel = "View All",
                onActionClick = { viewModel.navigateTo(AppDestination.WALLET) }
            )
        }

        if (transactions.isEmpty()) {
            item {
                EmptyStateView(
                    icon = Icons.Default.ReceiptLong,
                    title = "No Transactions Yet",
                    message = "Complete your first Watch & Earn video to earn verified coins!"
                )
            }
        } else {
            val recentList = transactions.take(4)
            items(recentList.size) { index ->
                val tx = recentList[index]
                TransactionItemRow(tx = tx)
            }
        }
    }
}

@Composable
fun QuickActionButton(
    title: String,
    icon: ImageVector,
    accent: Color = PurplePrimary,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(DarkSurface)
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = PurplePrimary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = DarkTextSecondary,
            fontSize = 10.sp,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun TransactionItemRow(
    tx: CoinTransactionEntity,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val isPositive = tx.amount > 0
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isPositive) PurpleDark else Color(0xFF451A1A)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (tx.type) {
                            "AD_REWARD" -> Icons.Default.PlayCircle
                            "DAILY_BONUS" -> Icons.Default.CalendarToday
                            "TASK_REWARD" -> Icons.Default.AssignmentTurnedIn
                            "REFERRAL_REWARD" -> Icons.Default.CardGiftcard
                            "WITHDRAWAL" -> Icons.Default.AccountBalanceWallet
                            "REVERSAL" -> Icons.Default.Undo
                            else -> Icons.Default.MonetizationOn
                        },
                        contentDescription = tx.type,
                        tint = if (isPositive) PurplePrimary else StatusDanger,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = tx.description,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = SimpleDateFormat("MMM dd, hh:mm a", Locale.US).format(Date(tx.createdAt)),
                        style = MaterialTheme.typography.labelSmall,
                        color = DarkTextSecondary
                    )
                }
            }

            Text(
                text = "${if (tx.amount > 0) "+" else ""}${tx.amount} Coins",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (tx.amount > 0) PurplePrimary else StatusDanger
            )
        }
    }
}
