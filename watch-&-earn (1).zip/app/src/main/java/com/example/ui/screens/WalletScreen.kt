package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CoinTransactionEntity
import com.example.data.model.WithdrawalEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class WalletTab {
    WITHDRAW,
    HISTORY,
    TRANSACTIONS
}

@Composable
fun WalletScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val wallet by viewModel.currentWallet.collectAsState()
    val withdrawals by viewModel.userWithdrawals.collectAsState()
    val transactions by viewModel.currentTransactions.collectAsState()
    val pendingWithdrawal by viewModel.pendingWithdrawalAmount.collectAsState()

    var currentTab by remember { mutableStateOf(WalletTab.WITHDRAW) }

    // Withdrawal Form State
    var selectedMethod by remember { mutableStateOf("Mobile Wallet") }
    var accountIdentifier by remember { mutableStateOf("") }
    var coinAmountText by remember { mutableStateOf("") }

    val availableCoins = wallet?.availableBalance ?: 0L
    val lockedCoins = wallet?.lockedBalance ?: 0L
    val totalCoins = availableCoins + lockedCoins

    val inputCoins = coinAmountText.toLongOrNull() ?: 0L
    val conversionRate = 1000L // 1000 Coins = $1.00 USD
    val calculatedUsd = inputCoins.toDouble() / conversionRate

    val methods = listOf("Mobile Wallet", "Bank Transfer", "PayPal", "Crypto (USDT)")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Balance Summary Card (Spec #5 & #6)
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Available Balance",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${NumberFormat.getNumberInstance(Locale.US).format(availableCoins)} Coins",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = String.format(Locale.US, "≈ $%.2f USD (Rate: 1,000 Coins = $1.00)", availableCoins.toDouble() / 1000.0),
                                style = MaterialTheme.typography.labelSmall,
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        CoinBadgePill(coins = availableCoins)
                    }

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "Locked / In Review",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${NumberFormat.getNumberInstance(Locale.US).format(lockedCoins)} Coins",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (lockedCoins > 0) StatusPending else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Column {
                            Text(
                                text = "Total Portfolio",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${NumberFormat.getNumberInstance(Locale.US).format(totalCoins)} Coins",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // 2. Navigation Tabs
        item {
            TabRow(
                selectedTabIndex = currentTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                divider = {}
            ) {
                Tab(
                    selected = currentTab == WalletTab.WITHDRAW,
                    onClick = { currentTab = WalletTab.WITHDRAW },
                    text = { Text("Request Payout") },
                    modifier = Modifier.testTag("tab_withdraw")
                )
                Tab(
                    selected = currentTab == WalletTab.HISTORY,
                    onClick = { currentTab = WalletTab.HISTORY },
                    text = { Text("Payouts (${withdrawals.size})") },
                    modifier = Modifier.testTag("tab_payout_history")
                )
                Tab(
                    selected = currentTab == WalletTab.TRANSACTIONS,
                    onClick = { currentTab = WalletTab.TRANSACTIONS },
                    text = { Text("Transactions") },
                    modifier = Modifier.testTag("tab_transactions")
                )
            }
        }

        // Tab Content
        when (currentTab) {
            WalletTab.WITHDRAW -> {
                item {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "Withdrawal Form",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            // Payment Method Selector
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "Select Payout Method",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    methods.take(2).forEach { method ->
                                        FilterChip(
                                            selected = selectedMethod == method,
                                            onClick = { selectedMethod = method },
                                            label = { Text(method, fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    methods.drop(2).forEach { method ->
                                        FilterChip(
                                            selected = selectedMethod == method,
                                            onClick = { selectedMethod = method },
                                            label = { Text(method, fontSize = 11.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // Payment Identifier Input
                            OutlinedTextField(
                                value = accountIdentifier,
                                onValueChange = { accountIdentifier = it },
                                label = {
                                    Text(
                                        when (selectedMethod) {
                                            "Mobile Wallet" -> "Phone / Venmo Handle"
                                            "PayPal" -> "PayPal Email Address"
                                            "Bank Transfer" -> "Bank Account / IBAN"
                                            else -> "USDT Wallet Address (TRC20)"
                                        }
                                    )
                                },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("withdrawal_identifier_input")
                            )

                            // Amount in Coins Input
                            OutlinedTextField(
                                value = coinAmountText,
                                onValueChange = {
                                    if (it.all { char -> char.isDigit() }) {
                                        coinAmountText = it
                                    }
                                },
                                label = { Text("Amount (Coins)") },
                                placeholder = { Text("Min: 500 Coins") },
                                trailingIcon = {
                                    TextButton(
                                        onClick = { coinAmountText = availableCoins.toString() }
                                    ) {
                                        Text("MAX", fontWeight = FontWeight.Bold, color = EmeraldPrimary)
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("withdrawal_amount_input")
                            )

                            // Real-time conversion readout
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Estimated Payout Value:",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = String.format(Locale.US, "$%.2f USD", calculatedUsd),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldPrimary
                                    )
                                }
                            }

                            // Submit Button
                            val isValid = inputCoins in 500..availableCoins && accountIdentifier.isNotBlank()
                            Button(
                                onClick = {
                                    viewModel.submitWithdrawal(inputCoins, selectedMethod, accountIdentifier)
                                    coinAmountText = ""
                                    accountIdentifier = ""
                                    currentTab = WalletTab.HISTORY
                                },
                                enabled = isValid,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("submit_withdrawal_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                            ) {
                                Text(
                                    text = if (inputCoins > availableCoins) "Insufficient Balance" else if (inputCoins < 500) "Minimum 500 Coins" else "Submit Withdrawal Request",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            WalletTab.HISTORY -> {
                if (withdrawals.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.Payments,
                            title = "No Withdrawal History",
                            message = "You haven't requested any payouts yet. Reach 500 Coins to make your first withdrawal!"
                        )
                    }
                } else {
                    items(withdrawals) { with ->
                        WithdrawalHistoryCard(withdrawal = with)
                    }
                }
            }

            WalletTab.TRANSACTIONS -> {
                if (transactions.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.ReceiptLong,
                            title = "No Transactions Found",
                            message = "Your coin earnings and spending history will appear here."
                        )
                    }
                } else {
                    items(transactions) { tx ->
                        TransactionItemRow(tx = tx)
                    }
                }
            }
        }
    }
}

@Composable
fun WithdrawalHistoryCard(
    withdrawal: WithdrawalEntity,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("withdrawal_card_${withdrawal.id}")
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = withdrawal.method,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = withdrawal.paymentIdentifier,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                StatusChip(status = withdrawal.status)
            }

            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.US).format(Date(withdrawal.createdAt)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "-${withdrawal.amount} Coins ($${String.format(Locale.US, "%.2f", withdrawal.amount / 1000.0)})",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            if (!withdrawal.adminNote.isNullOrBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Note: ${withdrawal.adminNote}",
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(8.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
