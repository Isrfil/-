package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.CoinBadgePill
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: MainViewModel = viewModel()
) {
    val currentDestination by viewModel.currentDestination.collectAsState()
    val authState by viewModel.authUiState.collectAsState()
    val wallet by viewModel.currentWallet.collectAsState()
    val unreadNotifs by viewModel.unreadNotifCount.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.toastMessage.collectLatest { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
        }
    }

    if (authState.currentUser == null) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            contentWindowInsets = WindowInsets.systemBars
        ) { innerPadding ->
            AuthScreen(
                viewModel = viewModel,
                modifier = Modifier.padding(innerPadding)
            )
        }
        return
    }

    Scaffold(
        topBar = {
            if (currentDestination != AppDestination.ADMIN) {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(PurplePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = PurpleDark,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Text(
                                text = "Watch & Earn",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    },
                    actions = {
                        // Coin Pill Badge
                        CoinBadgePill(
                            coins = wallet?.availableBalance ?: 0L,
                            onClick = { viewModel.navigateTo(AppDestination.WALLET) },
                            modifier = Modifier.testTag("topbar_coin_pill")
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Admin Shortcut Button
                        IconButton(
                            onClick = { viewModel.loginAsAdmin() },
                            modifier = Modifier.testTag("topbar_admin_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Console",
                                tint = if (authState.currentUser?.role == "ADMIN") PurplePrimary else DarkTextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkBg,
                        titleContentColor = Color.White
                    )
                )
            }
        },
        bottomBar = {
            if (currentDestination != AppDestination.ADMIN) {
                NavigationBar(
                    containerColor = DarkBg,
                    tonalElevation = 0.dp,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    val navItemColors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PurpleDark,
                        selectedTextColor = PurplePrimary,
                        indicatorColor = PurplePrimary,
                        unselectedIconColor = DarkTextSecondary,
                        unselectedTextColor = DarkTextSecondary
                    )

                    NavigationBarItem(
                        selected = currentDestination == AppDestination.HOME,
                        onClick = { viewModel.navigateTo(AppDestination.HOME) },
                        icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                        label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentDestination == AppDestination.EARN,
                        onClick = { viewModel.navigateTo(AppDestination.EARN) },
                        icon = { Icon(Icons.Default.PlayCircle, contentDescription = "Earn") },
                        label = { Text("Earn", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_earn")
                    )

                    NavigationBarItem(
                        selected = currentDestination == AppDestination.TASKS,
                        onClick = { viewModel.navigateTo(AppDestination.TASKS) },
                        icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = "Tasks") },
                        label = { Text("Tasks", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_tasks")
                    )

                    NavigationBarItem(
                        selected = currentDestination == AppDestination.WALLET,
                        onClick = { viewModel.navigateTo(AppDestination.WALLET) },
                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Wallet") },
                        label = { Text("Wallet", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_wallet")
                    )

                    NavigationBarItem(
                        selected = currentDestination == AppDestination.PROFILE,
                        onClick = { viewModel.navigateTo(AppDestination.PROFILE) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (unreadNotifs > 0) {
                                        Badge(containerColor = PurplePrimary, contentColor = PurpleDark) {
                                            Text("$unreadNotifs", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Person, contentDescription = "Profile")
                            }
                        },
                        label = { Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        colors = navItemColors,
                        modifier = Modifier.testTag("nav_profile")
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.systemBars
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                AppDestination.HOME -> HomeScreen(viewModel = viewModel)
                AppDestination.EARN -> WatchEarnScreen(viewModel = viewModel)
                AppDestination.TASKS -> TasksScreen(viewModel = viewModel)
                AppDestination.WALLET -> WalletScreen(viewModel = viewModel)
                AppDestination.PROFILE -> ProfileScreen(viewModel = viewModel)
                AppDestination.ADMIN -> AdminScreen(viewModel = viewModel)
            }
        }
    }
}
