package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.model.*
import com.example.data.repository.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppDestination {
    HOME,
    EARN,
    TASKS,
    WALLET,
    PROFILE,
    ADMIN
}

data class AuthUiState(
    val currentUser: UserEntity? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

data class WatchEarnUiState(
    val activeSession: RewardSessionEntity? = null,
    val activeAdConfig: AdConfigEntity? = null,
    val isWatching: Boolean = false,
    val isVerifying: Boolean = false,
    val playbackProgress: Float = 0f,
    val remainingSeconds: Int = 0,
    val verificationResult: VerificationResult? = null,
    val errorMessage: String? = null
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val rewardEngine = RewardEngine(database)
    val walletRepository = WalletRepository(database)
    val authRepository = AuthRepository(database)
    val taskRepository = TaskRepository(database)
    val adminRepository = AdminRepository(database)

    // Navigation & Screen selection
    private val _currentDestination = MutableStateFlow(AppDestination.HOME)
    val currentDestination: StateFlow<AppDestination> = _currentDestination.asStateFlow()

    // Auth State
    private val _authUiState = MutableStateFlow(AuthUiState())
    val authUiState: StateFlow<AuthUiState> = _authUiState.asStateFlow()

    // Watch & Earn State
    private val _watchEarnState = MutableStateFlow(WatchEarnUiState())
    val watchEarnState: StateFlow<WatchEarnUiState> = _watchEarnState.asStateFlow()

    // Feedback Toast / Snackbar message
    private val _toastMessage = MutableSharedFlow<String>()
    val toastMessage: SharedFlow<String> = _toastMessage.asSharedFlow()

    // Reactive Data Flows bound to Current User
    val currentWallet: StateFlow<WalletEntity?> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getWallet(userId) else flowOf(null)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentTransactions: StateFlow<List<CoinTransactionEntity>> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getTransactions(userId) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val todayEarnings: StateFlow<Long> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getTodayEarnings(userId).map { it ?: 0L } else flowOf(0L)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalEarnings: StateFlow<Long> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getTotalEarnings(userId).map { it ?: 0L } else flowOf(0L)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val userWithdrawals: StateFlow<List<WithdrawalEntity>> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getWithdrawals(userId) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingWithdrawalAmount: StateFlow<Long> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) walletRepository.getPendingWithdrawalAmount(userId).map { it ?: 0L } else flowOf(0L)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val userNotifications: StateFlow<List<NotificationEntity>> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) database.notificationDao().getNotificationsForUser(userId) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotifCount: StateFlow<Int> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) database.notificationDao().getUnreadCountForUser(userId) else flowOf(0)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Global Public Data Flows
    val adConfigs: StateFlow<List<AdConfigEntity>> = database.adConfigDao().getAllAdConfigs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeTasks: StateFlow<List<TaskEntity>> = taskRepository.getActiveTasks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userTaskCompletions: StateFlow<List<TaskCompletionEntity>> = _authUiState
        .map { it.currentUser?.id }
        .distinctUntilChanged()
        .flatMapLatest { userId ->
            if (userId != null) taskRepository.getUserTaskCompletions(userId) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Admin Data Flows
    val adminAllUsers: StateFlow<List<UserEntity>> = adminRepository.getAllUsers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAllWithdrawals: StateFlow<List<WithdrawalEntity>> = adminRepository.getAllWithdrawals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAllFraudFlags: StateFlow<List<FraudFlagEntity>> = adminRepository.getAllFraudFlags()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminAllLogs: StateFlow<List<AdminLogEntity>> = adminRepository.getAllAdminLogs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSettings: StateFlow<List<SettingEntity>> = adminRepository.getAllSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Streak status
    private val _streakDay = MutableStateFlow(5)
    val streakDay: StateFlow<Int> = _streakDay.asStateFlow()

    private val _isDailyClaimedToday = MutableStateFlow(false)
    val isDailyClaimedToday: StateFlow<Boolean> = _isDailyClaimedToday.asStateFlow()

    init {
        // Auto login default demo user for seamless start
        loginAsDemoUser()
    }

    fun navigateTo(destination: AppDestination) {
        _currentDestination.value = destination
    }

    fun login(email: String, pass: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _authUiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = authRepository.loginUser(email, pass)
            result.onSuccess { user ->
                _authUiState.update { it.copy(currentUser = user, isLoading = false, errorMessage = null) }
                refreshDailyBonusStatus(user.id)
                _toastMessage.emit("Welcome back, ${user.name}!")
            }.onFailure { err ->
                _authUiState.update { it.copy(isLoading = false, errorMessage = err.message) }
            }
        }
    }

    fun register(name: String, email: String, pass: String, referralCode: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            _authUiState.update { it.copy(isLoading = true, errorMessage = null) }
            val result = authRepository.registerUser(name, email, pass, referralCode)
            result.onSuccess { user ->
                _authUiState.update { it.copy(currentUser = user, isLoading = false, errorMessage = null) }
                refreshDailyBonusStatus(user.id)
                _toastMessage.emit("Account created successfully! Welcome, ${user.name}.")
            }.onFailure { err ->
                _authUiState.update { it.copy(isLoading = false, errorMessage = err.message) }
            }
        }
    }

    fun loginAsDemoUser() {
        viewModelScope.launch(Dispatchers.IO) {
            val user = authRepository.getUserById("user-demo-001")
            if (user != null) {
                _authUiState.value = AuthUiState(currentUser = user)
                refreshDailyBonusStatus(user.id)
            }
        }
    }

    fun loginAsAdmin() {
        viewModelScope.launch(Dispatchers.IO) {
            val admin = authRepository.getUserById("admin-primary-001")
            if (admin != null) {
                _authUiState.value = AuthUiState(currentUser = admin)
                _currentDestination.value = AppDestination.ADMIN
                _toastMessage.emit("Switched to Admin Console.")
            }
        }
    }

    fun logout() {
        _authUiState.value = AuthUiState(currentUser = null)
        _currentDestination.value = AppDestination.HOME
    }

    fun refreshDailyBonusStatus(userId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val (streak, claimed) = taskRepository.getDailyBonusStatus(userId)
            _streakDay.value = streak
            _isDailyClaimedToday.value = claimed
        }
    }

    fun claimDailyBonus() {
        val user = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = taskRepository.claimDailyBonus(user.id, _streakDay.value)
            result.onSuccess { reward ->
                _isDailyClaimedToday.value = true
                _toastMessage.emit("+$reward Coins Daily Bonus Claimed!")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to claim bonus.")
            }
        }
    }

    fun completeTask(taskId: String) {
        val user = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = taskRepository.completeCustomTask(user.id, taskId)
            result.onSuccess { reward ->
                _toastMessage.emit("Task completed! +$reward Coins added.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Task completion failed.")
            }
        }
    }

    // --- REWARD SESSION LIFECYCLE ---
    fun startWatchingAd(adConfig: AdConfigEntity) {
        val user = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _watchEarnState.value = WatchEarnUiState(
                activeAdConfig = adConfig,
                isWatching = true,
                remainingSeconds = 15,
                playbackProgress = 0f
            )

            val sessionResult = rewardEngine.startRewardSession(user.id, adConfig.id)
            sessionResult.onSuccess { session ->
                _watchEarnState.update { it.copy(activeSession = session) }
            }.onFailure { err ->
                _watchEarnState.update {
                    it.copy(
                        isWatching = false,
                        errorMessage = err.message ?: "Could not initiate reward session."
                    )
                }
                _toastMessage.emit(err.message ?: "Could not start ad.")
            }
        }
    }

    fun cancelWatchingAd() {
        _watchEarnState.value = WatchEarnUiState()
    }

    fun verifyWatchedAd(eventId: String, signatureToken: String) {
        val session = _watchEarnState.value.activeSession ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _watchEarnState.update { it.copy(isVerifying = true, isWatching = false) }

            // Backend Verification Call
            val result = rewardEngine.verifyRewardEvent(
                sessionId = session.id,
                providerEventId = eventId,
                signatureToken = signatureToken
            )

            _watchEarnState.update {
                it.copy(
                    isVerifying = false,
                    verificationResult = result
                )
            }

            when (result) {
                is VerificationResult.Success -> {
                    _toastMessage.emit(result.message)
                }
                is VerificationResult.Duplicate -> {
                    _toastMessage.emit(result.message)
                }
                is VerificationResult.Error -> {
                    _toastMessage.emit(result.message)
                }
            }
        }
    }

    fun submitWithdrawal(amount: Long, method: String, identifier: String) {
        val user = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = walletRepository.requestWithdrawal(user.id, amount, method, identifier)
            result.onSuccess {
                _toastMessage.emit("Withdrawal request for $amount Coins submitted successfully!")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Withdrawal request failed.")
            }
        }
    }

    fun markNotificationsRead() {
        val user = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            database.notificationDao().markAllAsRead(user.id)
        }
    }

    // --- ADMIN ACTIONS ---
    fun adminUpdateWithdrawalStatus(withdrawalId: String, newStatus: String, reason: String?) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = walletRepository.adminUpdateWithdrawalStatus(admin.id, withdrawalId, newStatus, reason)
            result.onSuccess {
                _toastMessage.emit("Withdrawal updated to $newStatus.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to update withdrawal.")
            }
        }
    }

    fun adminAdjustUserBalance(targetUserId: String, amount: Long, reason: String) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = walletRepository.adminAdjustBalance(admin.id, targetUserId, amount, reason)
            result.onSuccess {
                _toastMessage.emit("User balance successfully adjusted.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to adjust balance.")
            }
        }
    }

    fun adminSetUserStatus(targetUserId: String, status: String, reason: String) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.setUserStatus(admin.id, targetUserId, status, reason)
            result.onSuccess {
                _toastMessage.emit("User status set to $status.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to update user status.")
            }
        }
    }

    fun adminSaveAdConfig(config: AdConfigEntity) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.saveAdConfig(admin.id, config)
            result.onSuccess {
                _toastMessage.emit("Ad configuration '${config.id}' updated.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to save ad config.")
            }
        }
    }

    fun adminSaveTask(task: TaskEntity) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.saveTask(admin.id, task)
            result.onSuccess {
                _toastMessage.emit("Task saved successfully.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to save task.")
            }
        }
    }

    fun adminDeleteTask(task: TaskEntity) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.deleteTask(admin.id, task)
            result.onSuccess {
                _toastMessage.emit("Task deleted.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to delete task.")
            }
        }
    }

    fun adminResolveFraud(flagId: String, resolution: String) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.resolveFraudFlag(admin.id, flagId, resolution)
            result.onSuccess {
                _toastMessage.emit("Fraud flag marked as $resolution.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to resolve fraud flag.")
            }
        }
    }

    fun adminUpdateSetting(key: String, value: String) {
        val admin = _authUiState.value.currentUser ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val result = adminRepository.updateSetting(admin.id, key, value)
            result.onSuccess {
                _toastMessage.emit("Setting '$key' updated.")
            }.onFailure { err ->
                _toastMessage.emit(err.message ?: "Failed to update setting.")
            }
        }
    }
}
