package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MainViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val authState by viewModel.authUiState.collectAsState()
    val user = authState.currentUser
    val notifications by viewModel.userNotifications.collectAsState()
    val unreadCount by viewModel.unreadNotifCount.collectAsState()

    val clipboardManager = LocalClipboardManager.current
    var selectedPolicyTitle by remember { mutableStateOf<String?>(null) }
    var selectedPolicyContent by remember { mutableStateOf<String?>(null) }
    var showNotificationsSheet by remember { mutableStateOf(false) }

    // Policy Dialog
    if (selectedPolicyTitle != null && selectedPolicyContent != null) {
        AlertDialog(
            onDismissRequest = {
                selectedPolicyTitle = null
                selectedPolicyContent = null
            },
            title = {
                Text(
                    text = selectedPolicyTitle ?: "",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = selectedPolicyContent ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    selectedPolicyTitle = null
                    selectedPolicyContent = null
                }) {
                    Text("Close")
                }
            }
        )
    }

    // Notifications Dialog
    if (showNotificationsSheet) {
        AlertDialog(
            onDismissRequest = {
                showNotificationsSheet = false
                viewModel.markNotificationsRead()
            },
            title = {
                Text("Notifications & Alerts", fontWeight = FontWeight.Bold)
            },
            text = {
                if (notifications.isEmpty()) {
                    Text("No notifications at this time.")
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().heightIn(max = 360.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(notifications) { notif ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(10.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = notif.title,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = SimpleDateFormat("MMM dd", Locale.US).format(Date(notif.createdAt)),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text(
                                        text = notif.message,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showNotificationsSheet = false
                    viewModel.markNotificationsRead()
                }) {
                    Text("Mark Read & Close")
                }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. User Header Profile Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Column {
                                Text(
                                    text = user?.name ?: "Guest User",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = user?.email ?: "Not signed in",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        StatusChip(status = user?.role ?: "USER")
                    }

                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Account Status",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        StatusChip(status = user?.status ?: "NORMAL")
                    }
                }
            }
        }

        // 2. Referral Program Banner
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CardGiftcard,
                                contentDescription = null,
                                tint = CoinGoldDark
                            )
                            Text(
                                text = "Referral Program (+150 Coins)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }

                    Text(
                        text = "Share your invite code with friends. You earn +150 Coins when they join, and they receive +50 Coins welcome starter bonus!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CoinGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = user?.referralCode ?: "EARN77",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Button(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(user?.referralCode ?: "EARN77"))
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CoinGold, contentColor = Color.Black)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Copy Code", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 3. Notifications & Activity Center
        item {
            SectionHeader(title = "Account & System")
        }

        item {
            SettingsMenuCard(
                icon = Icons.Default.Notifications,
                title = "Notifications & Alerts",
                subtitle = if (unreadCount > 0) "$unreadCount unread updates" else "System messages & rewards",
                badge = if (unreadCount > 0) "$unreadCount" else null,
                onClick = { showNotificationsSheet = true }
            )
        }

        // 4. Legal & Compliance Policies (Spec #16)
        item {
            SectionHeader(title = "Policies & Legal Center")
        }

        item {
            SettingsMenuCard(
                icon = Icons.Default.VerifiedUser,
                title = "Reward Verification Policy",
                subtitle = "Rules on legitimate server-verified ad completions",
                onClick = {
                    selectedPolicyTitle = "Reward Verification Policy"
                    selectedPolicyContent = """
                        1. CORE EARNING PRINCIPLE
                        Watch & Earn utilizes a strict cryptographic verification engine. Coins are awarded exclusively when an authorized advertising provider returns a verified server completion event.
                        
                        2. PROHIBITED PRACTICES
                        - No coins are rewarded for clicking advertisements or opening external partner links.
                        - Forced redirects, auto-refreshing, and headless script loading are strictly blocked and filtered.
                        - Any attempts to tamper with signatures or replay reward completion tokens will result in automatic fraud flagging and account suspension.
                        
                        3. COOLDOWNS & DAILY LIMITS
                        Each rewarded format has a mandatory cooldown timer (30-60 seconds) and a daily completion cap (10-20 rewards) to protect ecosystem sustainability.
                    """.trimIndent()
                }
            )
        }

        item {
            SettingsMenuCard(
                icon = Icons.Default.Description,
                title = "Terms of Service",
                subtitle = "User agreements, payouts, and fair use guidelines",
                onClick = {
                    selectedPolicyTitle = "Terms of Service"
                    selectedPolicyContent = """
                        1. ACCEPTANCE OF TERMS
                        By creating an account on Watch & Earn, you agree to comply with all platform rules, withdrawal terms, and fair use guidelines.
                        
                        2. WALLET & PAYOUT POLICIES
                        - Available coins may be redeemed once minimum thresholds (500 Coins = $0.50 USD) are achieved.
                        - Payout requests undergo administrative review to ensure compliance with reward verification integrity.
                        
                        3. TERMINATION
                        We reserve the right to suspend or terminate accounts involved in fraudulent activities, emulator automation, or multi-accounting.
                    """.trimIndent()
                }
            )
        }

        item {
            SettingsMenuCard(
                icon = Icons.Default.PrivacyTip,
                title = "Privacy Policy",
                subtitle = "How your profile and activity logs are handled",
                onClick = {
                    selectedPolicyTitle = "Privacy Policy"
                    selectedPolicyContent = """
                        1. DATA COLLECTION
                        We securely retain account authentication details, transaction ledgers, and ad verification signatures to facilitate rewards and process payouts.
                        
                        2. ADVERTISING INTEGRATION
                        Third-party advertising SDKs and web scripts run in isolated sandboxes. We do not sell personally identifiable information to advertising brokers.
                    """.trimIndent()
                }
            )
        }

        // 5. Admin Switch & Session Controls
        item {
            SectionHeader(title = "Session Controls")
        }

        item {
            SettingsMenuCard(
                icon = Icons.Default.AdminPanelSettings,
                title = "Switch to Admin Console",
                subtitle = "Manage users, withdrawals, ad configs, and fraud review",
                onClick = {
                    viewModel.loginAsAdmin()
                }
            )
        }

        item {
            Button(
                onClick = { viewModel.logout() },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f), contentColor = MaterialTheme.colorScheme.error),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("logout_button")
            ) {
                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Log Out of Account", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SettingsMenuCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (badge != null) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(StatusDanger)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 10.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
