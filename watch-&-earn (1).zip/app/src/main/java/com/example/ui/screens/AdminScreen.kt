package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.MainViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AdminTab {
    OVERVIEW,
    USERS,
    WITHDRAWALS,
    ADS,
    TASKS,
    FRAUD,
    SETTINGS,
    LOGS
}

@Composable
fun AdminScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(AdminTab.OVERVIEW) }

    val users by viewModel.adminAllUsers.collectAsState()
    val withdrawals by viewModel.adminAllWithdrawals.collectAsState()
    val adConfigs by viewModel.adConfigs.collectAsState()
    val tasks by viewModel.activeTasks.collectAsState()
    val fraudFlags by viewModel.adminAllFraudFlags.collectAsState()
    val adminLogs by viewModel.adminAllLogs.collectAsState()
    val settings by viewModel.allSettings.collectAsState()

    // Dialog state for User Coin Adjustment
    var targetUserForAdjustment by remember { mutableStateOf<UserEntity?>(null) }
    var adjustAmountText by remember { mutableStateOf("") }
    var adjustReasonText by remember { mutableStateOf("") }

    // Dialog state for Withdrawal Rejection
    var targetWithdrawalForReject by remember { mutableStateOf<WithdrawalEntity?>(null) }
    var rejectReasonText by remember { mutableStateOf("") }

    // Dialog state for Editing Ad Config
    var editingAdConfig by remember { mutableStateOf<AdConfigEntity?>(null) }

    // User Balance Adjustment Dialog
    if (targetUserForAdjustment != null) {
        val u = targetUserForAdjustment!!
        AlertDialog(
            onDismissRequest = { targetUserForAdjustment = null },
            title = { Text("Adjust Coins: ${u.name}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("User ID: ${u.id}", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                    OutlinedTextField(
                        value = adjustAmountText,
                        onValueChange = { adjustAmountText = it },
                        label = { Text("Coin Amount (+ or -)") },
                        placeholder = { Text("e.g. 500 or -200") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = adjustReasonText,
                        onValueChange = { adjustReasonText = it },
                        label = { Text("Mandatory Reason") },
                        placeholder = { Text("e.g. Promotional grant or fraud correction") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = adjustAmountText.toLongOrNull()
                        if (amt != null && adjustReasonText.isNotBlank()) {
                            viewModel.adminAdjustUserBalance(u.id, amt, adjustReasonText)
                            targetUserForAdjustment = null
                            adjustAmountText = ""
                            adjustReasonText = ""
                        }
                    },
                    enabled = adjustAmountText.toLongOrNull() != null && adjustReasonText.isNotBlank()
                ) {
                    Text("Apply Adjustment")
                }
            },
            dismissButton = {
                TextButton(onClick = { targetUserForAdjustment = null }) { Text("Cancel") }
            }
        )
    }

    // Withdrawal Rejection Dialog (Requires Reason & Triggers Atomic Reversal)
    if (targetWithdrawalForReject != null) {
        val w = targetWithdrawalForReject!!
        AlertDialog(
            onDismissRequest = { targetWithdrawalForReject = null },
            title = { Text("Reject Withdrawal #${w.id.take(8)}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Amount: ${w.amount} Coins ($${w.amount / 1000.0}) to ${w.method}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        "Rejecting will automatically reverse ${w.amount} Coins back to the user's available balance.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = rejectReasonText,
                        onValueChange = { rejectReasonText = it },
                        label = { Text("Mandatory Rejection Reason") },
                        placeholder = { Text("e.g. Invalid account details, verification issue") },
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (rejectReasonText.isNotBlank()) {
                            viewModel.adminUpdateWithdrawalStatus(w.id, "REJECTED", rejectReasonText)
                            targetWithdrawalForReject = null
                            rejectReasonText = ""
                        }
                    },
                    enabled = rejectReasonText.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusDanger)
                ) {
                    Text("Reject & Reverse Coins")
                }
            },
            dismissButton = {
                TextButton(onClick = { targetWithdrawalForReject = null }) { Text("Cancel") }
            }
        )
    }

    // Ad Config Edit Dialog
    if (editingAdConfig != null) {
        var tempConfig by remember { mutableStateOf(editingAdConfig!!) }
        AlertDialog(
            onDismissRequest = { editingAdConfig = null },
            title = { Text("Edit Ad Placement: ${tempConfig.id}", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Provider: ${tempConfig.provider}", style = MaterialTheme.typography.bodySmall)
                    Text("Type: ${tempConfig.adType} | Placement: ${tempConfig.placement}", style = MaterialTheme.typography.bodySmall)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Status: ${tempConfig.status}", fontWeight = FontWeight.SemiBold)
                        Button(
                            onClick = {
                                tempConfig = tempConfig.copy(
                                    status = if (tempConfig.status == "ACTIVE") "PAUSED" else "ACTIVE"
                                )
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (tempConfig.status == "ACTIVE") "Pause" else "Activate")
                        }
                    }

                    if (tempConfig.adType == "REWARDED") {
                        OutlinedTextField(
                            value = tempConfig.rewardAmount.toString(),
                            onValueChange = { tempConfig = tempConfig.copy(rewardAmount = it.toLongOrNull() ?: 0L) },
                            label = { Text("Reward Coins") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    OutlinedTextField(
                        value = tempConfig.cooldownSeconds.toString(),
                        onValueChange = { tempConfig = tempConfig.copy(cooldownSeconds = it.toLongOrNull() ?: 30L) },
                        label = { Text("Cooldown (Seconds)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = tempConfig.dailyLimit.toString(),
                        onValueChange = { tempConfig = tempConfig.copy(dailyLimit = it.toIntOrNull() ?: 20) },
                        label = { Text("Daily Limit") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.adminSaveAdConfig(tempConfig)
                        editingAdConfig = null
                    }
                ) {
                    Text("Save Config")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingAdConfig = null }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Admin Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(CoinGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = CoinGoldDark,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Admin Panel",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "System moderation, payouts & ad management",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = {
                        viewModel.loginAsDemoUser()
                        viewModel.navigateTo(AppDestination.HOME)
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("exit_admin_button")
                ) {
                    Icon(Icons.Default.ExitToApp, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Exit Admin", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 2. Admin Horizontal Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                edgePadding = 0.dp,
                divider = {}
            ) {
                AdminTab.values().forEach { tab ->
                    Tab(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        text = {
                            Text(
                                text = when (tab) {
                                    AdminTab.OVERVIEW -> "Overview"
                                    AdminTab.USERS -> "Users (${users.size})"
                                    AdminTab.WITHDRAWALS -> "Withdrawals (${withdrawals.count { it.status == "PENDING" }} Pending)"
                                    AdminTab.ADS -> "Ad Configs (${adConfigs.size})"
                                    AdminTab.TASKS -> "Tasks"
                                    AdminTab.FRAUD -> "Fraud (${fraudFlags.size})"
                                    AdminTab.SETTINGS -> "Settings"
                                    AdminTab.LOGS -> "Audit Logs"
                                },
                                fontSize = 12.sp,
                                fontWeight = if (selectedTab == tab) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag("admin_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }

        // 3. Tab Content
        when (selectedTab) {
            AdminTab.OVERVIEW -> {
                item {
                    val pendingCount = withdrawals.count { it.status == "PENDING" }
                    val completedAmount = withdrawals.filter { it.status == "COMPLETED" }.sumOf { it.amount }

                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatCard(
                                title = "Total Users",
                                value = "${users.size}",
                                subtitle = "${users.count { it.role == "USER" }} standard users",
                                icon = Icons.Default.People,
                                accentColor = StatusInfo,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "Pending Payouts",
                                value = "$pendingCount",
                                subtitle = "Awaiting review",
                                icon = Icons.Default.PendingActions,
                                accentColor = if (pendingCount > 0) StatusWarning else EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            StatCard(
                                title = "Total Payouts Done",
                                value = "$${String.format(Locale.US, "%.2f", completedAmount / 1000.0)}",
                                subtitle = "$completedAmount coins finalized",
                                icon = Icons.Default.AccountBalanceWallet,
                                accentColor = EmeraldPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatCard(
                                title = "Active Ad Units",
                                value = "${adConfigs.count { it.status == "ACTIVE" }}/${adConfigs.size}",
                                subtitle = "${adConfigs.count { it.rewardEnabled }} rewarded",
                                icon = Icons.Default.AdsClick,
                                accentColor = CoinGoldDark,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            AdminTab.USERS -> {
                items(users) { user ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = user.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = user.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Ref: ${user.referralCode} | Role: ${user.role}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                StatusChip(status = user.status)
                            }

                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { targetUserForAdjustment = user },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CoinGold, contentColor = Color.Black),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Adjust Coins", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                if (user.status == "NORMAL") {
                                    OutlinedButton(
                                        onClick = { viewModel.adminSetUserStatus(user.id, "SUSPENDED", "Admin manual suspension") },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusDanger),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Suspend", fontSize = 11.sp)
                                    }
                                } else {
                                    OutlinedButton(
                                        onClick = { viewModel.adminSetUserStatus(user.id, "NORMAL", "Admin unsuspended") },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusSuccess),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Reactivate", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AdminTab.WITHDRAWALS -> {
                if (withdrawals.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.Payments,
                            title = "No Withdrawals",
                            message = "No withdrawal requests exist in the database."
                        )
                    }
                } else {
                    items(withdrawals) { with ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth().testTag("admin_withdrawal_card_${with.id}")
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "${with.amount} Coins ($${String.format(Locale.US, "%.2f", with.amount / 1000.0)})",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Method: ${with.method} • ${with.paymentIdentifier}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Text(
                                            text = "User ID: ${with.userId}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    StatusChip(status = with.status)
                                }

                                if (with.status == "PENDING" || with.status == "PROCESSING" || with.status == "APPROVED") {
                                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.adminUpdateWithdrawalStatus(with.id, "COMPLETED", "Payment completed by admin") },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.weight(1f).testTag("admin_complete_withdrawal_${with.id}")
                                        ) {
                                            Text("Mark Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = { targetWithdrawalForReject = with },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusDanger),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            modifier = Modifier.weight(1f).testTag("admin_reject_withdrawal_${with.id}")
                                        ) {
                                            Text("Reject & Refund", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AdminTab.ADS -> {
                item {
                    Text(
                        text = "Configured Ad Units (${adConfigs.size} placements)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                items(adConfigs) { ad ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${ad.id} • ${ad.title}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Provider: ${ad.provider} | Placement: ${ad.placement}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                StatusChip(status = ad.status)
                            }

                            Text(
                                text = "Format: ${ad.adType} | Reward Enabled: ${ad.rewardEnabled} (${ad.rewardAmount} Coins) | Cooldown: ${ad.cooldownSeconds}s | Daily Limit: ${ad.dailyLimit}",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                OutlinedButton(
                                    onClick = { editingAdConfig = ad },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Configure Unit", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            AdminTab.TASKS -> {
                items(tasks) { task ->
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Reward: ${task.reward} Coins | Daily Limit: ${task.dailyLimit} | Type: ${task.type}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            CoinBadgePill(coins = task.reward)
                        }
                    }
                }
            }

            AdminTab.FRAUD -> {
                if (fraudFlags.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.Shield,
                            title = "No Fraud Alerts",
                            message = "The fraud engine has not detected any suspicious reward activity."
                        )
                    }
                } else {
                    items(fraudFlags) { flag ->
                        Card(
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, StatusDanger.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "User ID: ${flag.userId}",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    StatusChip(status = flag.severity)
                                }
                                Text(
                                    text = "Reason: ${flag.reason}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    TextButton(onClick = { viewModel.adminResolveFraud(flag.id, "DISMISSED") }) {
                                        Text("Dismiss")
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Button(
                                        onClick = { viewModel.adminResolveFraud(flag.id, "RESOLVED") },
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                    ) {
                                        Text("Mark Resolved")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            AdminTab.SETTINGS -> {
                items(settings) { setting ->
                    var tempVal by remember { mutableStateOf(setting.value) }
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = setting.id,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Current Value: ${setting.value}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = {
                                    // Toggle or prompt
                                    if (setting.value == "false") viewModel.adminUpdateSetting(setting.id, "true")
                                    else if (setting.value == "true") viewModel.adminUpdateSetting(setting.id, "false")
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Toggle / Edit", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            AdminTab.LOGS -> {
                if (adminLogs.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Default.HistoryEdu,
                            title = "No Audit Logs",
                            message = "Admin action records will appear here."
                        )
                    }
                } else {
                    items(adminLogs) { log ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = log.action,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Text(
                                        text = SimpleDateFormat("MMM dd, hh:mm:ss a", Locale.US).format(Date(log.createdAt)),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = "Admin: ${log.adminId} • Target: ${log.targetType} [${log.targetId}]",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (!log.reason.isNullOrBlank()) {
                                    Text(
                                        text = "Reason: ${log.reason}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
