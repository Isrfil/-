package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark Palette
val DarkBg = Color(0xFF1C1B1F)
val DarkSurface = Color(0xFF2B2930)
val DarkSurfaceVariant = Color(0xFF36343B)
val DarkBorder = Color(0xFF49454F)
val DarkTextPrimary = Color(0xFFE6E1E5)
val DarkTextSecondary = Color(0xFF938F99)

// Luxury Violet / Lilac Accents
val PurplePrimary = Color(0xFFD0BCFF)
val PurpleDark = Color(0xFF381E72)
val PurpleMedium = Color(0xFF4F378B)
val PurpleLight = Color(0xFFE8DEF8)
val PurpleAccent = Color(0xFF6750A4)

// Coin Gold & Amber Accents
val CoinGold = Color(0xFFFACC15)
val CoinGoldLight = Color(0xFFFEF08A)
val CoinGoldDark = Color(0xFFCA8A04)

// Status Colors
val StatusSuccess = Color(0xFF4ADE80)
val StatusWarning = Color(0xFFFBBF24)
val StatusDanger = Color(0xFFF87171)
val StatusInfo = Color(0xFF60A5FA)
val StatusPending = Color(0xFFA78BFA)

// Legacy alias compatibility
val EmeraldPrimary = Color(0xFFD0BCFF)
val EmeraldDark = Color(0xFF381E72)
val EmeraldLight = Color(0xFFE8DEF8)
val EmeraldAccent = Color(0xFF4ADE80)

