package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        WalletEntity::class,
        CoinTransactionEntity::class,
        RewardSessionEntity::class,
        TaskEntity::class,
        TaskCompletionEntity::class,
        WithdrawalEntity::class,
        AdConfigEntity::class,
        NotificationEntity::class,
        FraudFlagEntity::class,
        AdminLogEntity::class,
        SettingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun walletDao(): WalletDao
    abstract fun coinTransactionDao(): CoinTransactionDao
    abstract fun rewardSessionDao(): RewardSessionDao
    abstract fun taskDao(): TaskDao
    abstract fun withdrawalDao(): WithdrawalDao
    abstract fun adConfigDao(): AdConfigDao
    abstract fun notificationDao(): NotificationDao
    abstract fun fraudFlagDao(): FraudFlagDao
    abstract fun adminLogDao(): AdminLogDao
    abstract fun settingDao(): SettingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "watch_earn_database"
                )
                    .addCallback(DatabaseCallback(context.applicationContext, scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val context: Context,
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        DatabaseSeeder.seedDatabase(database)
                    }
                }
            }
        }
    }
}
