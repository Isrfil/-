package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class AdminDashboardStats(
    val totalUsers: Int = 0,
    val newUsersToday: Int = 0,
    val totalCoinsIssued: Long = 0L,
    val pendingWithdrawalsCount: Int = 0,
    val totalCompletedWithdrawalsAmount: Long = 0L,
    val totalCompletedRewardsCount: Int = 0,
    val activeAdsCount: Int = 0
)

class AdminRepository(
    private val database: AppDatabase
) {
    private val userDao = database.userDao()
    private val walletDao = database.walletDao()
    private val txDao = database.coinTransactionDao()
    private val rewardDao = database.rewardSessionDao()
    private val withdrawalDao = database.withdrawalDao()
    private val adConfigDao = database.adConfigDao()
    private val taskDao = database.taskDao()
    private val fraudDao = database.fraudFlagDao()
    private val adminLogDao = database.adminLogDao()
    private val settingDao = database.settingDao()

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()
    fun getAllWithdrawals(): Flow<List<WithdrawalEntity>> = withdrawalDao.getAllWithdrawals()
    fun getAllAdConfigs(): Flow<List<AdConfigEntity>> = adConfigDao.getAllAdConfigs()
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()
    fun getAllFraudFlags(): Flow<List<FraudFlagEntity>> = fraudDao.getAllFraudFlags()
    fun getAllAdminLogs(): Flow<List<AdminLogEntity>> = adminLogDao.getAllAdminLogs()
    fun getAllSettings(): Flow<List<SettingEntity>> = settingDao.getAllSettings()

    suspend fun setUserStatus(adminId: String, userId: String, status: String, reason: String): Result<Unit> {
        userDao.updateUserStatus(userId, status)
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "USER_STATUS_$status",
                targetType = "USER",
                targetId = userId,
                reason = reason
            )
        )
        return Result.success(Unit)
    }

    suspend fun saveAdConfig(adminId: String, config: AdConfigEntity): Result<Unit> {
        // Enforce Core Rule: Only REWARDED ad type can have rewardEnabled = true
        val safeConfig = if (config.adType != "REWARDED") {
            config.copy(rewardEnabled = false, rewardAmount = 0L, updatedAt = System.currentTimeMillis())
        } else {
            config.copy(updatedAt = System.currentTimeMillis())
        }

        adConfigDao.insertOrUpdateAdConfig(safeConfig)
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "AD_CONFIG_SAVE",
                targetType = "AD_CONFIG",
                targetId = safeConfig.id,
                reason = "Updated placement ${safeConfig.placement} (rewardEnabled=${safeConfig.rewardEnabled})"
            )
        )
        return Result.success(Unit)
    }

    suspend fun saveTask(adminId: String, task: TaskEntity): Result<Unit> {
        taskDao.insertTask(task)
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "TASK_SAVE",
                targetType = "TASK",
                targetId = task.id,
                reason = "Saved task: ${task.title}"
            )
        )
        return Result.success(Unit)
    }

    suspend fun deleteTask(adminId: String, task: TaskEntity): Result<Unit> {
        taskDao.deleteTask(task)
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "TASK_DELETE",
                targetType = "TASK",
                targetId = task.id,
                reason = "Deleted task: ${task.title}"
            )
        )
        return Result.success(Unit)
    }

    suspend fun resolveFraudFlag(adminId: String, flagId: String, resolution: String): Result<Unit> {
        fraudDao.updateFlagStatus(flagId, resolution)
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "FRAUD_FLAG_RESOLVE",
                targetType = "FRAUD_FLAG",
                targetId = flagId,
                reason = "Resolution: $resolution"
            )
        )
        return Result.success(Unit)
    }

    suspend fun updateSetting(adminId: String, key: String, value: String): Result<Unit> {
        settingDao.setSetting(SettingEntity(id = key, value = value))
        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "SETTING_UPDATE",
                targetType = "SETTINGS",
                targetId = key,
                reason = "Set $key = $value"
            )
        )
        return Result.success(Unit)
    }
}
