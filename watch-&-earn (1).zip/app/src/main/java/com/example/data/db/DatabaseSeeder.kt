package com.example.data.db

import com.example.data.model.*
import java.util.UUID

object DatabaseSeeder {
    suspend fun seedDatabase(database: AppDatabase) {
        val userDao = database.userDao()
        val walletDao = database.walletDao()
        val transactionDao = database.coinTransactionDao()
        val taskDao = database.taskDao()
        val adConfigDao = database.adConfigDao()
        val notificationDao = database.notificationDao()
        val settingDao = database.settingDao()
        val withdrawalDao = database.withdrawalDao()

        val adminUserId = "admin-primary-001"
        val demoUserId = "user-demo-001"

        // 1. Seed Users
        val adminUser = UserEntity(
            id = adminUserId,
            name = "System Admin",
            email = "admin@watchearn.io",
            passwordHash = "admin123",
            role = "ADMIN",
            status = "NORMAL",
            referralCode = "ADMIN99",
            emailVerified = true,
            createdAt = System.currentTimeMillis() - 86400000L * 30
        )
        val demoUser = UserEntity(
            id = demoUserId,
            name = "Alex Mercer",
            email = "user@watchearn.io",
            passwordHash = "user123",
            role = "USER",
            status = "NORMAL",
            referralCode = "EARN77",
            referredBy = null,
            emailVerified = true,
            createdAt = System.currentTimeMillis() - 86400000L * 7
        )

        userDao.insertUser(adminUser)
        userDao.insertUser(demoUser)

        // 2. Seed Wallets
        walletDao.insertOrUpdateWallet(
            WalletEntity(
                id = "wallet-admin-001",
                userId = adminUserId,
                availableBalance = 100000L,
                lockedBalance = 0L
            )
        )
        walletDao.insertOrUpdateWallet(
            WalletEntity(
                id = "wallet-user-001",
                userId = demoUserId,
                availableBalance = 12450L,
                lockedBalance = 500L
            )
        )

        // 3. Seed Transactions for Demo User
        val now = System.currentTimeMillis()
        val sampleTransactions = listOf(
            CoinTransactionEntity(
                userId = demoUserId,
                amount = 100L,
                type = "AD_REWARD",
                referenceId = "sess-init-01",
                description = "Watch Verified Sponsored Video",
                createdAt = now - 3600000L * 2
            ),
            CoinTransactionEntity(
                userId = demoUserId,
                amount = 50L,
                type = "DAILY_BONUS",
                referenceId = "day-5-bonus",
                description = "Day 5 Login Bonus",
                createdAt = now - 3600000L * 6
            ),
            CoinTransactionEntity(
                userId = demoUserId,
                amount = 700L,
                type = "TASK_REWARD",
                referenceId = "task-profile-init",
                description = "Profile Verification Reward",
                createdAt = now - 3600000L * 12
            ),
            CoinTransactionEntity(
                userId = demoUserId,
                amount = 150L,
                type = "REFERRAL_REWARD",
                referenceId = "ref-user-99",
                description = "Referral Bonus: Friend Joined",
                createdAt = now - 86400000L * 1
            ),
            CoinTransactionEntity(
                userId = demoUserId,
                amount = -500L,
                type = "WITHDRAWAL",
                referenceId = "with-pending-01",
                description = "Withdrawal Request to Mobile Wallet",
                createdAt = now - 3600000L * 4
            )
        )
        for (tx in sampleTransactions) {
            transactionDao.insertTransaction(tx)
        }

        // 4. Seed Pending Withdrawal for Demo User
        withdrawalDao.insertWithdrawal(
            WithdrawalEntity(
                id = "with-pending-01",
                userId = demoUserId,
                amount = 500L,
                method = "Mobile Wallet",
                paymentIdentifier = "+1-555-019-2834 (Venmo)",
                status = "PENDING",
                adminNote = null,
                createdAt = now - 3600000L * 4
            )
        )

        // 5. Seed Tasks
        val tasks = listOf(
            TaskEntity(
                id = "task-daily-streak",
                title = "Daily Check-in Streak",
                description = "Log in every consecutive day to earn multiplying coin bonuses up to 100 coins.",
                type = "DAILY_BONUS",
                reward = 50L,
                dailyLimit = 1,
                iconName = "calendar"
            ),
            TaskEntity(
                id = "task-watch-3-ads",
                title = "Watch 3 Sponsored Ads",
                description = "Watch and verify 3 approved rewarded video advertisements.",
                type = "REWARDED_AD",
                reward = 150L,
                dailyLimit = 1,
                iconName = "play_circle"
            ),
            TaskEntity(
                id = "task-refer-friend",
                title = "Invite a Friend",
                description = "Share your unique referral code with friends. Receive instant bonus upon their signup.",
                type = "CUSTOM_TASK",
                reward = 200L,
                dailyLimit = 5,
                iconName = "group_add"
            ),
            TaskEntity(
                id = "task-complete-survey",
                title = "App Experience Survey",
                description = "Provide brief feedback on app responsiveness and ad playback.",
                type = "CUSTOM_TASK",
                reward = 300L,
                dailyLimit = 1,
                iconName = "poll"
            )
        )
        for (task in tasks) {
            taskDao.insertTask(task)
        }

        // 6. Seed All 14 Provided WEB_AD Configurations (Spec #17 & #34)
        val adConfigs = listOf(
            AdConfigEntity(
                id = "WEB_AD_01",
                provider = "profitableratecpmnetwork.com",
                adType = "DIRECT_LINK",
                placement = "HOME_TOP",
                scriptOrUrl = "https://www.profitableratecpmnetwork.com/c3pucy6cev?key=b1469a9cd6a618b4ebf76871b0eefb1f",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false, // Per spec: normal placement, no reward on link open
                status = "ACTIVE",
                title = "Featured Partner Link",
                description = "Direct web partner placement (Informational only, no direct coins)"
            ),
            AdConfigEntity(
                id = "WEB_AD_02",
                provider = "profitableratecpmnetwork.com",
                adType = "DISPLAY",
                placement = "HOME_MIDDLE",
                scriptOrUrl = "https://pl30995952.profitableratecpmnetwork.com/99/05/3b/99053b9ef7170d353fc50a51f6ebe98c.js",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Banner Showcase 01",
                description = "Standard display ad script"
            ),
            AdConfigEntity(
                id = "WEB_AD_03",
                provider = "profitableratecpmnetwork.com",
                adType = "DISPLAY",
                placement = "EARN_PAGE",
                scriptOrUrl = "https://pl30995951.profitableratecpmnetwork.com/3302d5f98a444a7dabfd50e0f8a393c0/invoke.js",
                containerId = "container-3302d5f98a444a7dabfd50e0f8a393c0",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Invoked Banner Unit",
                description = "Containerized display placement"
            ),
            AdConfigEntity(
                id = "WEB_AD_04",
                provider = "profitableratecpmnetwork.com",
                adType = "POPUP",
                placement = "BETWEEN_CONTENT",
                scriptOrUrl = "https://pl30995950.profitableratecpmnetwork.com/6c/7d/9f/6c7d9f432f750cb65ec376ccc799155e.js",
                rewardAmount = 0L,
                cooldownSeconds = 90L,
                dailyLimit = 10,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Content Interstitial",
                description = "Standard interstitial ad placement"
            ),
            AdConfigEntity(
                id = "WEB_AD_05",
                provider = "5gvci.com",
                adType = "DISPLAY",
                placement = "HOME_BOTTOM",
                scriptOrUrl = "https://5gvci.com/act/files/tag.min.js?z=10587764",
                zoneId = "10587764",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Tag Zone 10587764",
                description = "Standard dynamic display ad"
            ),
            AdConfigEntity(
                id = "WEB_AD_06",
                provider = "al5sm.com",
                adType = "DISPLAY",
                placement = "TASK_PAGE",
                scriptOrUrl = "https://al5sm.com/tag.min.js",
                zoneId = "10587765",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Dynamic Zone 10587765",
                description = "al5sm tag zone configuration"
            ),
            AdConfigEntity(
                id = "WEB_AD_07",
                provider = "omg10.com",
                adType = "DIRECT_LINK",
                placement = "ARTICLE_PAGE",
                scriptOrUrl = "https://omg10.com/4/10706350",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 15,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Direct Offer 10706350",
                description = "Direct offer URL placement"
            ),
            AdConfigEntity(
                id = "WEB_AD_08",
                provider = "nap5k.com",
                adType = "DISPLAY",
                placement = "WALLET_PAGE",
                scriptOrUrl = "https://nap5k.com/tag.min.js",
                zoneId = "10706367",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 15,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Wallet Footer Banner",
                description = "nap5k display zone 10706367"
            ),
            AdConfigEntity(
                id = "WEB_AD_09",
                provider = "n6wxm.com",
                adType = "VIGNETTE",
                placement = "BETWEEN_CONTENT",
                scriptOrUrl = "https://n6wxm.com/vignette.min.js",
                zoneId = "10787773",
                rewardAmount = 0L,
                cooldownSeconds = 120L,
                dailyLimit = 10,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Vignette Zone 10787773",
                description = "n6wxm full-page vignette placement"
            ),
            AdConfigEntity(
                id = "WEB_AD_10",
                provider = "5gvci.com",
                adType = "DISPLAY",
                placement = "EARN_PAGE",
                scriptOrUrl = "https://5gvci.com/act/files/tag.min.js?z=10587764",
                zoneId = "10587764",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 15,
                rewardEnabled = false,
                status = "PAUSED", // Marked paused to avoid duplicate loading with WEB_AD_05 per spec #17
                title = "Secondary Tag Zone",
                description = "Duplicate of WEB_AD_05 (Paused to prevent collision)"
            ),
            AdConfigEntity(
                id = "WEB_AD_11",
                provider = "nap5k.com",
                adType = "DISPLAY",
                placement = "HOME_MIDDLE",
                scriptOrUrl = "https://nap5k.com/tag.min.js",
                zoneId = "10587760",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Middle Tag Zone 10587760",
                description = "nap5k standard ad placement"
            ),
            AdConfigEntity(
                id = "WEB_AD_12",
                provider = "n6wxm.com",
                adType = "VIGNETTE",
                placement = "ARTICLE_PAGE",
                scriptOrUrl = "https://n6wxm.com/vignette.min.js",
                zoneId = "10587758",
                rewardAmount = 0L,
                cooldownSeconds = 120L,
                dailyLimit = 10,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Article Vignette 10587758",
                description = "Vignette overlay unit"
            ),
            AdConfigEntity(
                id = "WEB_AD_13",
                provider = "quge5.com",
                adType = "DISPLAY",
                placement = "HOME_TOP",
                scriptOrUrl = "https://quge5.com/88/tag.min.js",
                zoneId = "209643",
                rewardAmount = 0L,
                cooldownSeconds = 60L,
                dailyLimit = 20,
                rewardEnabled = false,
                status = "ACTIVE",
                title = "Quge5 Zone 209643",
                description = "Quge5 top display header"
            ),
            AdConfigEntity(
                id = "WEB_AD_14",
                provider = "nap5k.com",
                adType = "REWARDED",
                placement = "EARN_PAGE",
                scriptOrUrl = "https://nap5k.com/tag.min.js",
                zoneId = "10587752",
                rewardAmount = 100L,
                cooldownSeconds = 30L,
                dailyLimit = 15,
                rewardEnabled = true, // Officially supported verified rewarded format!
                status = "ACTIVE",
                title = "Watch Sponsored Ad (nap5k Rewarded)",
                description = "Watch verified 15s video ad to completion and receive +100 Coins after backend verification."
            ),
            AdConfigEntity(
                id = "WEB_AD_PREMIUM_01",
                provider = "verified-ad-network.io",
                adType = "REWARDED",
                placement = "EARN_PAGE",
                scriptOrUrl = "https://cdn.verified-ad-network.io/sdk/rewarded.js",
                zoneId = "889920",
                rewardAmount = 150L,
                cooldownSeconds = 45L,
                dailyLimit = 10,
                rewardEnabled = true, // Approved Rewarded Video
                status = "ACTIVE",
                title = "Premium Sponsor Video Ad",
                description = "High-yield sponsored interactive placement with verifiable server completion token."
            )
        )
        adConfigDao.insertAll(adConfigs)

        // 7. Seed System Notifications
        val notifications = listOf(
            NotificationEntity(
                userId = demoUserId,
                title = "Welcome to Watch & Earn!",
                message = "Earn coins securely by watching verified rewarded ads and completing daily tasks. Check out our Reward Policy for details.",
                createdAt = now - 86400000L * 7
            ),
            NotificationEntity(
                userId = demoUserId,
                title = "+100 Coins Credited",
                message = "Your ad reward session was successfully verified and added to your available coin balance.",
                createdAt = now - 3600000L * 2
            ),
            NotificationEntity(
                userId = demoUserId,
                title = "Withdrawal Submitted",
                message = "Your withdrawal request for 500 Coins ($0.50) is currently pending admin review.",
                createdAt = now - 3600000L * 4
            )
        )
        for (notif in notifications) {
            notificationDao.insertNotification(notif)
        }

        // 8. Seed Settings
        val settings = listOf(
            SettingEntity(id = "app_name", value = "Watch & Earn"),
            SettingEntity(id = "coin_conversion_rate", value = "1000"), // 1000 Coins = $1.00 USD
            SettingEntity(id = "min_withdrawal_coins", value = "500"),
            SettingEntity(id = "max_daily_withdrawal_coins", value = "50000"),
            SettingEntity(id = "default_cooldown_seconds", value = "30"),
            SettingEntity(id = "default_daily_reward_limit", value = "20"),
            SettingEntity(id = "referral_reward_coins", value = "150"),
            SettingEntity(id = "maintenance_mode", value = "false"),
            SettingEntity(id = "announcement", value = "Welcome to Watch & Earn! Earn real coins with verified reward ads and instant withdrawal processing.")
        )
        settingDao.insertAll(settings)
    }
}
