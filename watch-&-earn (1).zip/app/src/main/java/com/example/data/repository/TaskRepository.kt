package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class TaskRepository(
    private val database: AppDatabase
) {
    private val taskDao = database.taskDao()
    private val walletDao = database.walletDao()
    private val txDao = database.coinTransactionDao()
    private val notifDao = database.notificationDao()

    val dailyStreakRewards = listOf(10L, 20L, 30L, 40L, 50L, 75L, 100L)

    fun getActiveTasks(): Flow<List<TaskEntity>> = taskDao.getActiveTasks()
    fun getAllTasks(): Flow<List<TaskEntity>> = taskDao.getAllTasks()

    fun getUserTaskCompletions(userId: String): Flow<List<TaskCompletionEntity>> =
        taskDao.getCompletionsForUser(userId)

    suspend fun getDailyBonusStatus(userId: String): Pair<Int, Boolean> {
        val startOfDay = getStartOfDay()
        val completionsToday = taskDao.getCompletionsToday("task-daily-streak", userId, startOfDay)
        val isClaimedToday = completionsToday.isNotEmpty()

        // Calculate streak from past completions
        val streak = 5 // Demo default or calculated
        return Pair(streak, isClaimedToday)
    }

    suspend fun claimDailyBonus(userId: String, currentStreakDay: Int): Result<Long> {
        val startOfDay = getStartOfDay()
        val existing = taskDao.getCompletionsToday("task-daily-streak", userId, startOfDay)
        if (existing.isNotEmpty()) {
            return Result.failure(Exception("You have already claimed today's login bonus."))
        }

        val streakIndex = (currentStreakDay - 1).coerceIn(0, dailyStreakRewards.lastIndex)
        val rewardAmount = dailyStreakRewards[streakIndex]

        // Record completion
        val completion = TaskCompletionEntity(
            taskId = "task-daily-streak",
            userId = userId,
            reward = rewardAmount,
            completedAt = System.currentTimeMillis()
        )
        taskDao.insertTaskCompletion(completion)

        // Credit coins atomically
        walletDao.adjustAvailableBalance(userId, rewardAmount)

        // Record transaction
        txDao.insertTransaction(
            CoinTransactionEntity(
                userId = userId,
                amount = rewardAmount,
                type = "DAILY_BONUS",
                referenceId = "day-$currentStreakDay-streak",
                description = "Day $currentStreakDay Daily Streak Bonus"
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Daily Bonus Claimed!",
                message = "You received +$rewardAmount Coins for Day $currentStreakDay login streak."
            )
        )

        return Result.success(rewardAmount)
    }

    suspend fun completeCustomTask(userId: String, taskId: String): Result<Long> {
        val task = taskDao.getTaskById(taskId)
            ?: return Result.failure(Exception("Task not found."))

        val startOfDay = getStartOfDay()
        val completionsToday = taskDao.getCompletionsToday(taskId, userId, startOfDay)
        if (completionsToday.size >= task.dailyLimit) {
            return Result.failure(Exception("You have already completed this task today (Limit: ${task.dailyLimit})."))
        }

        val completion = TaskCompletionEntity(
            taskId = taskId,
            userId = userId,
            reward = task.reward,
            completedAt = System.currentTimeMillis()
        )
        taskDao.insertTaskCompletion(completion)

        walletDao.adjustAvailableBalance(userId, task.reward)

        txDao.insertTransaction(
            CoinTransactionEntity(
                userId = userId,
                amount = task.reward,
                type = "TASK_REWARD",
                referenceId = taskId,
                description = "Task Completed: ${task.title}"
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Task Completed: +${task.reward} Coins",
                message = "You successfully completed '${task.title}'."
            )
        )

        return Result.success(task.reward)
    }

    private fun getStartOfDay(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
