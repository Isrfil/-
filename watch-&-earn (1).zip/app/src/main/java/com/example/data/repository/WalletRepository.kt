package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class WalletRepository(
    private val database: AppDatabase
) {
    private val walletDao = database.walletDao()
    private val txDao = database.coinTransactionDao()
    private val withdrawalDao = database.withdrawalDao()
    private val notifDao = database.notificationDao()
    private val adminLogDao = database.adminLogDao()
    private val settingDao = database.settingDao()

    fun getWallet(userId: String): Flow<WalletEntity?> = walletDao.observeWalletByUserId(userId)

    fun getTransactions(userId: String): Flow<List<CoinTransactionEntity>> =
        txDao.getTransactionsForUser(userId)

    fun getTodayEarnings(userId: String): Flow<Long?> {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return txDao.getTodayEarnings(userId, cal.timeInMillis)
    }

    fun getTotalEarnings(userId: String): Flow<Long?> = txDao.getTotalEarnings(userId)

    fun getWithdrawals(userId: String): Flow<List<WithdrawalEntity>> =
        withdrawalDao.getWithdrawalsForUser(userId)

    fun getPendingWithdrawalAmount(userId: String): Flow<Long?> =
        withdrawalDao.getPendingWithdrawalForUser(userId)

    suspend fun requestWithdrawal(
        userId: String,
        amount: Long,
        method: String,
        paymentIdentifier: String
    ): Result<WithdrawalEntity> {
        if (amount <= 0) {
            return Result.failure(Exception("Withdrawal amount must be greater than zero."))
        }

        val minStr = settingDao.getSettingValue("min_withdrawal_coins") ?: "500"
        val minAmount = minStr.toLongOrNull() ?: 500L
        if (amount < minAmount) {
            return Result.failure(Exception("Minimum withdrawal is $minAmount Coins."))
        }

        val maxStr = settingDao.getSettingValue("max_daily_withdrawal_coins") ?: "50000"
        val maxAmount = maxStr.toLongOrNull() ?: 50000L
        if (amount > maxAmount) {
            return Result.failure(Exception("Maximum withdrawal is $maxAmount Coins."))
        }

        val wallet = walletDao.getWalletByUserId(userId)
            ?: return Result.failure(Exception("Wallet not found."))

        if (wallet.availableBalance < amount) {
            return Result.failure(Exception("Insufficient coin balance."))
        }

        // Lock coins atomically
        val rowsUpdated = walletDao.lockCoinsForWithdrawal(userId, amount)
        if (rowsUpdated == 0) {
            return Result.failure(Exception("Could not lock coins. Insufficient balance or concurrent update."))
        }

        val withdrawal = WithdrawalEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            amount = amount,
            method = method,
            paymentIdentifier = paymentIdentifier,
            status = "PENDING",
            createdAt = System.currentTimeMillis()
        )
        withdrawalDao.insertWithdrawal(withdrawal)

        val tx = CoinTransactionEntity(
            userId = userId,
            amount = -amount,
            type = "WITHDRAWAL",
            referenceId = withdrawal.id,
            description = "Withdrawal request to $method ($paymentIdentifier)"
        )
        txDao.insertTransaction(tx)

        notifDao.insertNotification(
            NotificationEntity(
                userId = userId,
                title = "Withdrawal Request Submitted",
                message = "Your request to withdraw $amount Coins to $method is currently pending admin review."
            )
        )

        return Result.success(withdrawal)
    }

    suspend fun adminUpdateWithdrawalStatus(
        adminId: String,
        withdrawalId: String,
        newStatus: String,
        adminReason: String? = null
    ): Result<Unit> {
        val withdrawal = withdrawalDao.getWithdrawalById(withdrawalId)
            ?: return Result.failure(Exception("Withdrawal request not found."))

        if (withdrawal.status == "COMPLETED" || withdrawal.status == "REJECTED") {
            return Result.failure(Exception("Withdrawal has already been finalized as ${withdrawal.status}."))
        }

        val now = System.currentTimeMillis()

        when (newStatus) {
            "REJECTED" -> {
                if (adminReason.isNullOrBlank()) {
                    return Result.failure(Exception("Rejection reason is required."))
                }
                // Atomic Reversal of locked coins
                walletDao.reverseLockedCoins(withdrawal.userId, withdrawal.amount)

                // Record reversal transaction
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = withdrawal.userId,
                        amount = withdrawal.amount,
                        type = "REVERSAL",
                        referenceId = withdrawal.id,
                        description = "Reversal for Rejected Withdrawal: $adminReason"
                    )
                )

                withdrawalDao.updateWithdrawal(
                    withdrawal.copy(
                        status = "REJECTED",
                        adminNote = adminReason,
                        processedAt = now
                    )
                )

                notifDao.insertNotification(
                    NotificationEntity(
                        userId = withdrawal.userId,
                        title = "Withdrawal Rejected & Refunded",
                        message = "Your withdrawal of ${withdrawal.amount} Coins was rejected. Reason: $adminReason. Coins have been restored."
                    )
                )

                adminLogDao.insertAdminLog(
                    AdminLogEntity(
                        adminId = adminId,
                        action = "WITHDRAWAL_REJECT",
                        targetType = "WITHDRAWAL",
                        targetId = withdrawal.id,
                        reason = adminReason
                    )
                )
            }
            "COMPLETED" -> {
                // Deduct locked coins permanently
                walletDao.finalizeDeduction(withdrawal.userId, withdrawal.amount)

                withdrawalDao.updateWithdrawal(
                    withdrawal.copy(
                        status = "COMPLETED",
                        adminNote = adminReason ?: "Payment Sent Successfully",
                        processedAt = now
                    )
                )

                notifDao.insertNotification(
                    NotificationEntity(
                        userId = withdrawal.userId,
                        title = "Withdrawal Completed!",
                        message = "Your withdrawal of ${withdrawal.amount} Coins has been processed and paid out to ${withdrawal.method}."
                    )
                )

                adminLogDao.insertAdminLog(
                    AdminLogEntity(
                        adminId = adminId,
                        action = "WITHDRAWAL_COMPLETE",
                        targetType = "WITHDRAWAL",
                        targetId = withdrawal.id,
                        reason = adminReason ?: "Processed successfully"
                    )
                )
            }
            "PROCESSING", "APPROVED" -> {
                withdrawalDao.updateWithdrawal(
                    withdrawal.copy(
                        status = newStatus,
                        adminNote = adminReason,
                        processedAt = now
                    )
                )

                adminLogDao.insertAdminLog(
                    AdminLogEntity(
                        adminId = adminId,
                        action = "WITHDRAWAL_$newStatus",
                        targetType = "WITHDRAWAL",
                        targetId = withdrawal.id,
                        reason = adminReason ?: "Status updated to $newStatus"
                    )
                )
            }
        }
        return Result.success(Unit)
    }

    suspend fun adminAdjustBalance(
        adminId: String,
        targetUserId: String,
        amount: Long,
        reason: String
    ): Result<Unit> {
        if (reason.isBlank()) {
            return Result.failure(Exception("A mandatory reason must be provided for balance adjustments."))
        }

        val wallet = walletDao.getWalletByUserId(targetUserId)
            ?: return Result.failure(Exception("Target user wallet not found."))

        if (amount < 0 && wallet.availableBalance + amount < 0) {
            return Result.failure(Exception("Cannot adjust balance below zero."))
        }

        walletDao.adjustAvailableBalance(targetUserId, amount)

        txDao.insertTransaction(
            CoinTransactionEntity(
                userId = targetUserId,
                amount = amount,
                type = "ADMIN_ADJUSTMENT",
                description = "Admin adjustment: $reason"
            )
        )

        adminLogDao.insertAdminLog(
            AdminLogEntity(
                adminId = adminId,
                action = "USER_ADJUST_COINS",
                targetType = "USER",
                targetId = targetUserId,
                reason = "Amount: $amount | Reason: $reason"
            )
        )

        notifDao.insertNotification(
            NotificationEntity(
                userId = targetUserId,
                title = "Balance Adjusted by Admin",
                message = "Your coin balance was adjusted by ${if (amount > 0) "+$amount" else "$amount"} Coins. Reason: $reason"
            )
        )

        return Result.success(Unit)
    }
}
