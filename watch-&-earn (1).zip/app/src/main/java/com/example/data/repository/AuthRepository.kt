package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class AuthRepository(
    private val database: AppDatabase
) {
    private val userDao = database.userDao()
    private val walletDao = database.walletDao()
    private val txDao = database.coinTransactionDao()
    private val notifDao = database.notificationDao()
    private val settingDao = database.settingDao()

    suspend fun registerUser(
        name: String,
        email: String,
        passwordHash: String,
        referralCodeInput: String?
    ): Result<UserEntity> {
        val existing = userDao.getUserByEmail(email.trim().lowercase())
        if (existing != null) {
            return Result.failure(Exception("An account with this email address already exists."))
        }

        val myReferralCode = generateUniqueReferralCode(name)
        val user = UserEntity(
            name = name.trim(),
            email = email.trim().lowercase(),
            passwordHash = passwordHash,
            role = "USER",
            status = "NORMAL",
            referralCode = myReferralCode,
            referredBy = referralCodeInput?.trim()?.takeIf { it.isNotBlank() },
            emailVerified = true
        )

        userDao.insertUser(user)

        // Initialize empty wallet
        val wallet = WalletEntity(
            userId = user.id,
            availableBalance = 0L,
            lockedBalance = 0L
        )
        walletDao.insertOrUpdateWallet(wallet)

        // Process referral reward if valid
        if (!user.referredBy.isNullOrBlank()) {
            val referrer = userDao.getUserByReferralCode(user.referredBy)
            if (referrer != null && referrer.id != user.id) {
                val rewardStr = settingDao.getSettingValue("referral_reward_coins") ?: "150"
                val rewardAmount = rewardStr.toLongOrNull() ?: 150L

                // Reward referrer
                walletDao.adjustAvailableBalance(referrer.id, rewardAmount)
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = referrer.id,
                        amount = rewardAmount,
                        type = "REFERRAL_REWARD",
                        referenceId = user.id,
                        description = "Referral Reward: ${user.name} joined"
                    )
                )
                notifDao.insertNotification(
                    NotificationEntity(
                        userId = referrer.id,
                        title = "+$rewardAmount Coins Referral Bonus!",
                        message = "Your friend ${user.name} joined using your code ${user.referralCode}."
                    )
                )

                // Welcome starter bonus for referred user (50 coins)
                walletDao.adjustAvailableBalance(user.id, 50L)
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = user.id,
                        amount = 50L,
                        type = "REFERRAL_REWARD",
                        referenceId = referrer.id,
                        description = "Welcome Bonus for joining with referral code"
                    )
                )
            }
        }

        notifDao.insertNotification(
            NotificationEntity(
                userId = user.id,
                title = "Welcome to Watch & Earn!",
                message = "Your account has been created. Start watching verified rewarded ads and completing daily tasks."
            )
        )

        return Result.success(user)
    }

    suspend fun loginUser(email: String, passwordAttempt: String): Result<UserEntity> {
        val user = userDao.getUserByEmail(email.trim().lowercase())
            ?: return Result.failure(Exception("Invalid email address or password."))

        if (user.passwordHash != passwordAttempt) {
            return Result.failure(Exception("Invalid email address or password."))
        }

        if (user.status == "SUSPENDED") {
            return Result.failure(Exception("Your account is suspended. Please contact support."))
        }

        return Result.success(user)
    }

    suspend fun resetPassword(email: String, newPasswordHash: String): Result<Unit> {
        val user = userDao.getUserByEmail(email.trim().lowercase())
            ?: return Result.failure(Exception("No account found with this email."))

        userDao.updateUser(user.copy(passwordHash = newPasswordHash, updatedAt = System.currentTimeMillis()))
        return Result.success(Unit)
    }

    suspend fun getUserById(userId: String): UserEntity? = userDao.getUserById(userId)

    fun getAllUsers(): Flow<List<UserEntity>> = userDao.getAllUsers()

    private fun generateUniqueReferralCode(name: String): String {
        val clean = name.filter { it.isLetterOrDigit() }.uppercase().take(4)
        val rand = (1000..9999).random()
        return if (clean.length >= 2) "$clean$rand" else "EARN$rand"
    }
}
