package com.example.data.db

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE referralCode = :code LIMIT 1")
    suspend fun getUserByReferralCode(code: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE role = 'USER' ORDER BY createdAt DESC")
    fun getAllStandardUsers(): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users")
    fun getUserCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM users WHERE createdAt >= :startOfDay")
    fun getNewUsersTodayCount(startOfDay: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity)

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET status = :status, updatedAt = :timestamp WHERE id = :userId")
    suspend fun updateUserStatus(userId: String, status: String, timestamp: Long = System.currentTimeMillis())
}

@Dao
interface WalletDao {
    @Query("SELECT * FROM wallets WHERE userId = :userId LIMIT 1")
    suspend fun getWalletByUserId(userId: String): WalletEntity?

    @Query("SELECT * FROM wallets WHERE userId = :userId LIMIT 1")
    fun observeWalletByUserId(userId: String): Flow<WalletEntity?>

    @Query("SELECT SUM(availableBalance) FROM wallets")
    fun getTotalAvailableCoins(): Flow<Long?>

    @Query("SELECT SUM(lockedBalance) FROM wallets")
    fun getTotalLockedCoins(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateWallet(wallet: WalletEntity)

    @Query("UPDATE wallets SET availableBalance = availableBalance + :delta, updatedAt = :timestamp WHERE userId = :userId")
    suspend fun adjustAvailableBalance(userId: String, delta: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE wallets SET availableBalance = availableBalance - :amount, lockedBalance = lockedBalance + :amount, updatedAt = :timestamp WHERE userId = :userId AND availableBalance >= :amount")
    suspend fun lockCoinsForWithdrawal(userId: String, amount: Long, timestamp: Long = System.currentTimeMillis()): Int

    @Query("UPDATE wallets SET availableBalance = availableBalance + :amount, lockedBalance = lockedBalance - :amount, updatedAt = :timestamp WHERE userId = :userId AND lockedBalance >= :amount")
    suspend fun reverseLockedCoins(userId: String, amount: Long, timestamp: Long = System.currentTimeMillis()): Int

    @Query("UPDATE wallets SET lockedBalance = lockedBalance - :amount, updatedAt = :timestamp WHERE userId = :userId AND lockedBalance >= :amount")
    suspend fun finalizeDeduction(userId: String, amount: Long, timestamp: Long = System.currentTimeMillis()): Int
}

@Dao
interface CoinTransactionDao {
    @Query("SELECT * FROM coin_transactions WHERE userId = :userId ORDER BY createdAt DESC")
    fun getTransactionsForUser(userId: String): Flow<List<CoinTransactionEntity>>

    @Query("SELECT * FROM coin_transactions ORDER BY createdAt DESC LIMIT 100")
    fun getAllTransactions(): Flow<List<CoinTransactionEntity>>

    @Query("SELECT SUM(amount) FROM coin_transactions WHERE userId = :userId AND amount > 0 AND createdAt >= :startOfDay")
    fun getTodayEarnings(userId: String, startOfDay: Long): Flow<Long?>

    @Query("SELECT SUM(amount) FROM coin_transactions WHERE userId = :userId AND amount > 0")
    fun getTotalEarnings(userId: String): Flow<Long?>

    @Query("SELECT SUM(amount) FROM coin_transactions WHERE amount > 0")
    fun getTotalCoinsIssued(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: CoinTransactionEntity)
}

@Dao
interface RewardSessionDao {
    @Query("SELECT * FROM reward_sessions WHERE id = :sessionId LIMIT 1")
    suspend fun getSessionById(sessionId: String): RewardSessionEntity?

    @Query("SELECT * FROM reward_sessions WHERE providerEventId = :eventId LIMIT 1")
    suspend fun getSessionByEventId(eventId: String): RewardSessionEntity?

    @Query("SELECT * FROM reward_sessions WHERE userId = :userId ORDER BY createdAt DESC")
    fun getSessionsForUser(userId: String): Flow<List<RewardSessionEntity>>

    @Query("SELECT COUNT(*) FROM reward_sessions WHERE userId = :userId AND status = 'COMPLETED' AND createdAt >= :startOfDay")
    suspend fun getCompletedRewardsTodayCount(userId: String, startOfDay: Long): Int

    @Query("SELECT * FROM reward_sessions WHERE userId = :userId AND status = 'COMPLETED' ORDER BY completedAt DESC LIMIT 1")
    suspend fun getLastCompletedRewardSession(userId: String): RewardSessionEntity?

    @Query("SELECT COUNT(*) FROM reward_sessions WHERE status = 'COMPLETED'")
    fun getTotalCompletedRewardsCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertSession(session: RewardSessionEntity)

    @Update
    suspend fun updateSession(session: RewardSessionEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY createdAt ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE status = 'ACTIVE' ORDER BY createdAt ASC")
    fun getActiveTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :taskId LIMIT 1")
    suspend fun getTaskById(taskId: String): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("SELECT * FROM task_completions WHERE taskId = :taskId AND userId = :userId AND completedAt >= :startOfDay")
    suspend fun getCompletionsToday(taskId: String, userId: String, startOfDay: Long): List<TaskCompletionEntity>

    @Query("SELECT * FROM task_completions WHERE userId = :userId ORDER BY completedAt DESC")
    fun getCompletionsForUser(userId: String): Flow<List<TaskCompletionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTaskCompletion(completion: TaskCompletionEntity)
}

@Dao
interface WithdrawalDao {
    @Query("SELECT * FROM withdrawals WHERE userId = :userId ORDER BY createdAt DESC")
    fun getWithdrawalsForUser(userId: String): Flow<List<WithdrawalEntity>>

    @Query("SELECT * FROM withdrawals ORDER BY createdAt DESC")
    fun getAllWithdrawals(): Flow<List<WithdrawalEntity>>

    @Query("SELECT * FROM withdrawals WHERE id = :id LIMIT 1")
    suspend fun getWithdrawalById(id: String): WithdrawalEntity?

    @Query("SELECT COUNT(*) FROM withdrawals WHERE status = 'PENDING'")
    fun getPendingWithdrawalsCount(): Flow<Int>

    @Query("SELECT SUM(amount) FROM withdrawals WHERE status = 'COMPLETED'")
    fun getTotalCompletedWithdrawalsAmount(): Flow<Long?>

    @Query("SELECT SUM(amount) FROM withdrawals WHERE userId = :userId AND status = 'PENDING'")
    fun getPendingWithdrawalForUser(userId: String): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWithdrawal(withdrawal: WithdrawalEntity)

    @Update
    suspend fun updateWithdrawal(withdrawal: WithdrawalEntity)
}

@Dao
interface AdConfigDao {
    @Query("SELECT * FROM ad_configs ORDER BY id ASC")
    fun getAllAdConfigs(): Flow<List<AdConfigEntity>>

    @Query("SELECT * FROM ad_configs WHERE placement = :placement AND status = 'ACTIVE'")
    fun getActiveConfigsForPlacement(placement: String): Flow<List<AdConfigEntity>>

    @Query("SELECT * FROM ad_configs WHERE id = :id LIMIT 1")
    suspend fun getAdConfigById(id: String): AdConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateAdConfig(adConfig: AdConfigEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(adConfigs: List<AdConfigEntity>)

    @Update
    suspend fun updateAdConfig(adConfig: AdConfigEntity)

    @Query("DELETE FROM ad_configs WHERE id = :id")
    suspend fun deleteAdConfig(id: String)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun getNotificationsForUser(userId: String): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND readAt IS NULL")
    fun getUnreadCountForUser(userId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Query("UPDATE notifications SET readAt = :timestamp WHERE userId = :userId AND readAt IS NULL")
    suspend fun markAllAsRead(userId: String, timestamp: Long = System.currentTimeMillis())
}

@Dao
interface FraudFlagDao {
    @Query("SELECT * FROM fraud_flags ORDER BY createdAt DESC")
    fun getAllFraudFlags(): Flow<List<FraudFlagEntity>>

    @Query("SELECT * FROM fraud_flags WHERE userId = :userId ORDER BY createdAt DESC")
    fun getFraudFlagsForUser(userId: String): Flow<List<FraudFlagEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFraudFlag(flag: FraudFlagEntity)

    @Query("UPDATE fraud_flags SET status = :status, resolvedAt = :timestamp WHERE id = :flagId")
    suspend fun updateFlagStatus(flagId: String, status: String, timestamp: Long = System.currentTimeMillis())
}

@Dao
interface AdminLogDao {
    @Query("SELECT * FROM admin_logs ORDER BY createdAt DESC LIMIT 200")
    fun getAllAdminLogs(): Flow<List<AdminLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminLog(log: AdminLogEntity)
}

@Dao
interface SettingDao {
    @Query("SELECT * FROM settings")
    fun getAllSettings(): Flow<List<SettingEntity>>

    @Query("SELECT value FROM settings WHERE id = :key LIMIT 1")
    suspend fun getSettingValue(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSetting(setting: SettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(settings: List<SettingEntity>)
}
