package com.example.data.repository

import com.example.data.db.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import java.security.MessageDigest
import java.util.UUID

sealed class VerificationResult {
    data class Success(val rewardAmount: Long, val newAvailableBalance: Long, val message: String) : VerificationResult()
    data class Duplicate(val message: String) : VerificationResult()
    data class Error(val message: String) : VerificationResult()
}

class RewardEngine(
    private val database: AppDatabase
) {
    private val sessionDao = database.rewardSessionDao()
    private val walletDao = database.walletDao()
    private val txDao = database.coinTransactionDao()
    private val adConfigDao = database.adConfigDao()
    private val userDao = database.userDao()
    private val notifDao = database.notificationDao()
    private val fraudDao = database.fraudFlagDao()

    suspend fun startRewardSession(userId: String, adConfigId: String): Result<RewardSessionEntity> {
        val user = userDao.getUserById(userId) ?: return Result.failure(Exception("User account not found."))
        if (user.status == "SUSPENDED") {
            return Result.failure(Exception("Your account is currently suspended. Earning is disabled."))
        }

        val adConfig = adConfigDao.getAdConfigById(adConfigId)
            ?: return Result.failure(Exception("Advertising placement not found."))

        if (adConfig.status != "ACTIVE") {
            return Result.failure(Exception("This advertising placement is currently paused or inactive."))
        }

        // Strict Core Rule #34: Only approved rewarded formats can generate rewards
        if (!adConfig.rewardEnabled) {
            return Result.failure(Exception("This advertising placement is for display only and does not support verified coin rewards."))
        }

        // Check Cooldown
        val lastSession = sessionDao.getLastCompletedRewardSession(userId)
        val now = System.currentTimeMillis()
        if (lastSession != null && lastSession.completedAt != null) {
            val elapsedSeconds = (now - lastSession.completedAt) / 1000
            val cooldown = adConfig.cooldownSeconds
            if (elapsedSeconds < cooldown) {
                val waitTime = cooldown - elapsedSeconds
                return Result.failure(Exception("Please wait $waitTime seconds before requesting another reward."))
            }
        }

        // Check Daily Limit
        val startOfDay = getStartOfDayTimestamp()
        val completedToday = sessionDao.getCompletedRewardsTodayCount(userId, startOfDay)
        if (completedToday >= adConfig.dailyLimit) {
            return Result.failure(Exception("You have reached the daily limit of ${adConfig.dailyLimit} rewards for this placement today."))
        }

        // Create new session with 10-minute expiration
        val session = RewardSessionEntity(
            id = UUID.randomUUID().toString(),
            userId = userId,
            adConfigId = adConfigId,
            provider = adConfig.provider,
            rewardAmount = adConfig.rewardAmount,
            status = "STARTED",
            expiresAt = now + (10 * 60 * 1000)
        )

        sessionDao.insertSession(session)
        return Result.success(session)
    }

    suspend fun verifyRewardEvent(
        sessionId: String,
        providerEventId: String,
        signatureToken: String
    ): VerificationResult {
        val now = System.currentTimeMillis()

        // 1. Anti-Duplicate Check (Idempotency Key)
        val existingWithEvent = sessionDao.getSessionByEventId(providerEventId)
        if (existingWithEvent != null) {
            return VerificationResult.Duplicate("Already processed. This reward event ($providerEventId) has already been accepted and credited.")
        }

        // 2. Fetch and Validate Session
        val session = sessionDao.getSessionById(sessionId)
            ?: return VerificationResult.Error("Reward session could not be found.")

        if (session.status == "COMPLETED") {
            return VerificationResult.Duplicate("This reward session has already been completed.")
        }

        if (now > session.expiresAt) {
            sessionDao.updateSession(session.copy(status = "EXPIRED"))
            return VerificationResult.Error("Reward session expired. Please start a new session.")
        }

        if (session.status != "STARTED") {
            return VerificationResult.Error("Reward session is in an invalid state: ${session.status}.")
        }

        // 3. Validate User Account Status
        val user = userDao.getUserById(session.userId)
            ?: return VerificationResult.Error("User account not found.")

        if (user.status == "SUSPENDED") {
            return VerificationResult.Error("User account is suspended. Reward cannot be issued.")
        }

        // 4. Verify Provider Signature / Integrity Token
        val expectedTokenPrefix = generateVerificationDigest("${session.id}:${session.provider}:${session.rewardAmount}")
        if (!signatureToken.startsWith(expectedTokenPrefix.take(8))) {
            return VerificationResult.Error("Reward could not be verified. Invalid provider signature.")
        }

        // 5. Fraud Detection Signal (Velocity check: 5 rewards in 2 minutes)
        val startOfWindow = now - 120000L
        val recentCount = sessionDao.getCompletedRewardsTodayCount(session.userId, startOfWindow)
        if (recentCount >= 5) {
            fraudDao.insertFraudFlag(
                FraudFlagEntity(
                    userId = session.userId,
                    reason = "Abnormal reward velocity ($recentCount completions in 2 minutes)",
                    severity = "HIGH",
                    status = "PENDING"
                )
            )
        }

        // 6. Atomic Transaction: Credit Coins & Complete Session
        try {
            val wallet = walletDao.getWalletByUserId(session.userId)
                ?: WalletEntity(userId = session.userId, availableBalance = 0L, lockedBalance = 0L)

            val newBalance = wallet.availableBalance + session.rewardAmount

            // Update wallet balance atomically
            walletDao.adjustAvailableBalance(session.userId, session.rewardAmount)

            // Record transaction
            val transaction = CoinTransactionEntity(
                userId = session.userId,
                amount = session.rewardAmount,
                type = "AD_REWARD",
                referenceId = session.id,
                description = "Watch Verified Ad (${session.provider})"
            )
            txDao.insertTransaction(transaction)

            // Mark session completed with provider event ID
            val updatedSession = session.copy(
                status = "COMPLETED",
                providerEventId = providerEventId,
                signature = signatureToken,
                completedAt = now
            )
            sessionDao.updateSession(updatedSession)

            // Issue notification
            notifDao.insertNotification(
                NotificationEntity(
                    userId = session.userId,
                    title = "+${session.rewardAmount} Coins Earned!",
                    message = "Your ad reward was successfully verified by ${session.provider} and added to your wallet."
                )
            )

            return VerificationResult.Success(
                rewardAmount = session.rewardAmount,
                newAvailableBalance = newBalance,
                message = "Reward verified! +${session.rewardAmount} Coins added to your balance."
            )
        } catch (e: Exception) {
            return VerificationResult.Error("Reward could not be verified due to a processing error: ${e.localizedMessage}")
        }
    }

    private fun generateVerificationDigest(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun getStartOfDayTimestamp(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
