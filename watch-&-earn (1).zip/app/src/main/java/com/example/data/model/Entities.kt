package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(
    tableName = "users",
    indices = [Index(value = ["email"], unique = true), Index(value = ["referralCode"], unique = true)]
)
data class UserEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val passwordHash: String,
    val role: String = "USER", // "USER", "ADMIN"
    val status: String = "NORMAL", // "NORMAL", "REVIEW", "SUSPENDED"
    val referralCode: String,
    val referredBy: String? = null,
    val emailVerified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "wallets",
    indices = [Index(value = ["userId"], unique = true)]
)
data class WalletEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val availableBalance: Long = 0L,
    val lockedBalance: Long = 0L,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "coin_transactions",
    indices = [Index(value = ["userId"]), Index(value = ["referenceId"])]
)
data class CoinTransactionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val amount: Long, // Positive for credits, negative for debits/locks
    val type: String, // "AD_REWARD", "TASK_REWARD", "DAILY_BONUS", "REFERRAL_REWARD", "WITHDRAWAL", "ADMIN_ADJUSTMENT", "REVERSAL", "REFUND"
    val referenceId: String? = null,
    val description: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "reward_sessions",
    indices = [Index(value = ["userId"]), Index(value = ["providerEventId"], unique = true)]
)
data class RewardSessionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val adConfigId: String,
    val provider: String,
    val providerEventId: String? = null, // Idempotency key
    val rewardAmount: Long,
    val status: String = "STARTED", // "STARTED", "VERIFIED", "COMPLETED", "FAILED", "EXPIRED"
    val signature: String? = null,
    val expiresAt: Long,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val type: String, // "REWARDED_AD", "DAILY_BONUS", "CUSTOM_TASK"
    val reward: Long,
    val dailyLimit: Int = 1,
    val totalLimit: Int = 100,
    val startsAt: Long = 0L,
    val endsAt: Long = Long.MAX_VALUE,
    val status: String = "ACTIVE", // "ACTIVE", "DISABLED"
    val iconName: String = "check_circle",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "task_completions",
    indices = [Index(value = ["taskId", "userId"])]
)
data class TaskCompletionEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val taskId: String,
    val userId: String,
    val reward: Long,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "withdrawals",
    indices = [Index(value = ["userId"])]
)
data class WithdrawalEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val amount: Long,
    val method: String, // "Mobile Wallet", "Bank Transfer", "PayPal / Crypto"
    val paymentIdentifier: String,
    val status: String = "PENDING", // "PENDING", "APPROVED", "PROCESSING", "COMPLETED", "REJECTED", "CANCELLED"
    val adminNote: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val processedAt: Long? = null
)

@Entity(tableName = "ad_configs")
data class AdConfigEntity(
    @PrimaryKey val id: String, // e.g. "WEB_AD_01"
    val provider: String,
    val adType: String, // "DISPLAY", "POPUP", "VIGNETTE", "DIRECT_LINK", "REWARDED"
    val placement: String, // "HOME_TOP", "HOME_MIDDLE", "HOME_BOTTOM", "EARN_PAGE", "TASK_PAGE", "WALLET_PAGE", "ARTICLE_PAGE", "BETWEEN_CONTENT"
    val scriptOrUrl: String,
    val containerId: String? = null,
    val zoneId: String? = null,
    val rewardAmount: Long = 0L,
    val cooldownSeconds: Long = 30L,
    val dailyLimit: Int = 10,
    val rewardEnabled: Boolean = false, // Per Core Rule: Only officially verified reward formats can be true
    val status: String = "ACTIVE", // "ACTIVE", "PAUSED", "INACTIVE"
    val title: String,
    val description: String,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "notifications",
    indices = [Index(value = ["userId"])]
)
data class NotificationEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val title: String,
    val message: String,
    val readAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "fraud_flags",
    indices = [Index(value = ["userId"])]
)
data class FraudFlagEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val userId: String,
    val reason: String,
    val severity: String = "MEDIUM", // "LOW", "MEDIUM", "HIGH"
    val status: String = "PENDING", // "PENDING", "REVIEWED", "DISMISSED"
    val createdAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null
)

@Entity(tableName = "admin_logs")
data class AdminLogEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val adminId: String,
    val action: String, // "USER_SUSPEND", "USER_ADJUST_COINS", "WITHDRAWAL_APPROVE", "WITHDRAWAL_REJECT", "SETTINGS_UPDATE", "TASK_UPDATE"
    val targetType: String, // "USER", "WITHDRAWAL", "TASK", "AD_CONFIG", "SETTINGS"
    val targetId: String,
    val reason: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "settings")
data class SettingEntity(
    @PrimaryKey val id: String, // Key
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)
