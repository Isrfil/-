package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.db.DatabaseSeeder
import com.example.data.repository.RewardEngine
import com.example.data.repository.VerificationResult
import com.example.data.repository.WalletRepository
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.security.MessageDigest

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var database: AppDatabase
    private lateinit var rewardEngine: RewardEngine
    private lateinit var walletRepository: WalletRepository

    @Before
    fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        runBlocking {
            DatabaseSeeder.seedDatabase(database)
        }
        rewardEngine = RewardEngine(database)
        walletRepository = WalletRepository(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context matches app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Watch & Earn", appName)
    }

    @Test
    fun `reward session lifecycle verifies legitimate event and rejects duplicates`() = runBlocking {
        val userId = "user-demo-001"
        val adId = "WEB_AD_14" // Rewarded ad with 100 coins

        // 1. Start Reward Session
        val startResult = rewardEngine.startRewardSession(userId, adId)
        assertTrue("Session start should succeed", startResult.isSuccess)
        val session = startResult.getOrThrow()
        assertEquals("STARTED", session.status)
        assertEquals(100L, session.rewardAmount)

        // 2. Generate Provider Event ID and Valid Signature
        val eventId = "TEST-EVT-998811"
        val expectedDigest = MessageDigest.getInstance("SHA-256")
            .digest("${session.id}:${session.provider}:${session.rewardAmount}".toByteArray())
            .joinToString("") { "%02x".format(it) }

        // 3. Verify Reward
        val verifyResult = rewardEngine.verifyRewardEvent(session.id, eventId, expectedDigest)
        assertTrue("Verification should succeed", verifyResult is VerificationResult.Success)
        val success = verifyResult as VerificationResult.Success
        assertEquals(100L, success.rewardAmount)

        // 4. Test Anti-Duplicate (Idempotency): Attempting to re-verify same event
        val duplicateResult = rewardEngine.verifyRewardEvent(session.id, eventId, expectedDigest)
        assertTrue("Duplicate event should be detected and blocked", duplicateResult is VerificationResult.Duplicate)
    }

    @Test
    fun `withdrawal requests lock coins and admin rejection reverses them atomically`() = runBlocking {
        val userId = "user-demo-001"
        val adminId = "admin-primary-001"

        val initialWallet = database.walletDao().getWalletByUserId(userId)!!
        val initialAvailable = initialWallet.availableBalance

        // 1. Request 1000 Coins Withdrawal
        val requestResult = walletRepository.requestWithdrawal(
            userId = userId,
            amount = 1000L,
            method = "PayPal",
            paymentIdentifier = "alex@test.com"
        )
        assertTrue(requestResult.isSuccess)
        val withdrawal = requestResult.getOrThrow()

        val lockedWallet = database.walletDao().getWalletByUserId(userId)!!
        assertEquals(initialAvailable - 1000L, lockedWallet.availableBalance)
        assertEquals(1500L, lockedWallet.lockedBalance) // 500 initial + 1000

        // 2. Admin Rejects Withdrawal with Reason
        val rejectResult = walletRepository.adminUpdateWithdrawalStatus(
            adminId = adminId,
            withdrawalId = withdrawal.id,
            newStatus = "REJECTED",
            adminReason = "Invalid PayPal account email"
        )
        assertTrue(rejectResult.isSuccess)

        // 3. Verify Coins Reversal
        val refundedWallet = database.walletDao().getWalletByUserId(userId)!!
        assertEquals(initialAvailable, refundedWallet.availableBalance)
        assertEquals(500L, refundedWallet.lockedBalance)
    }

    @Test
    fun `display ad configs strictly reject starting reward sessions`() = runBlocking {
        val userId = "user-demo-001"
        val displayAdId = "WEB_AD_01" // Direct link / display, rewardEnabled = false

        val startResult = rewardEngine.startRewardSession(userId, displayAdId)
        assertTrue("Should reject reward session on display unit", startResult.isFailure)
        assertTrue(startResult.exceptionOrNull()?.message?.contains("does not support verified coin rewards") == true)
    }
}
